import { GoogleGenAI } from '@google/genai';

const apiKey = process.env.GEMINI_API_KEY || '';

export const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface BookContextItem {
  id: string;
  name: string;
  category: string;
  content: string;
  rules?: string[];
  keyLessons?: string[];
}

export interface MarketContextItem {
  symbol: string;
  displayName: string;
  timeframe: string;
  currentPrice: number;
  bid: number;
  ask: number;
  change24h: number;
  high24h: number;
  low24h: number;
  ema20: number;
  ema50: number;
  rsi: number;
  trend: 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS';
  recentCandles: {
    time: string;
    open: number;
    high: number;
    low: number;
    close: number;
    volume: number;
  }[];
}

/**
 * Perform trading analysis based on uploaded books and current MT5 chart data
 */
export async function analyzeMarketWithBooks({
  market,
  books,
  userQuery,
  imageData,
}: {
  market: MarketContextItem;
  books: BookContextItem[];
  userQuery?: string;
  imageData?: { base64: string; mimeType: string };
}) {
  const booksText = books.length > 0
    ? books.map((b, i) => `[KITOB ${i + 1}: "${b.name}" (${b.category})]\nAsosiy qoidalar va mazmuni:\n${b.content}`).join('\n\n')
    : 'Yuklangan kitoblar mavjud emas. Standart klassik Price Action, ICT/SMC va Wyckoff metodologiyasidan foydalaning.';

  const recentCandlesText = market.recentCandles.slice(-15).map(c => 
    `${c.time}: O=${c.open.toFixed(2)}, H=${c.high.toFixed(2)}, L=${c.low.toFixed(2)}, C=${c.close.toFixed(2)}, V=${c.volume}`
  ).join('\n');

  const systemInstruction = `Siz professional MT5 AI Trading Mentor va Analitiksisiz.
Sizning vazifangiz: Foydalanuvchining real vaqt MT5 bozori grafigini va YUKLANGAN KITOB LARIDAGI (Smart Money Concepts/ICT, Wyckoff, Price Action, Risk Management va h.k.) qoidalarni birlashtirib, chuqur, asosli va aniq maslahat berish.

MUHIM QOIDALAR:
1. Har bir tahlil va maslahatda yuklangan kitoblar qoidalariga aniq havola (iqtibos) keltiring (masalan: "Kitobingizdagi 'Smart Money Concepts' bo'yicha...", "Wyckoff qoidasiga binoan...").
2. Bozordagi narx, EMA 20 (${market.ema20.toFixed(2)}), EMA 50 (${market.ema50.toFixed(2)}), RSI (${market.rsi.toFixed(1)}), Support/Resistance va hajm (volume) ko'rsatkichlariga tayanib xulosa chiqaring.
3. Agar signal bersangiz: Buy/Sell/Kutish (Wait), Kirish narxi (Entry), Stop Loss (SL), Take Profit (TP), Risk-Reward nisbati (kamida 1:2) va tavsiya etiladigan lot hajmini qat'iy ko'rsating.
4. O'zbek tilida ravon, professional, lekin tushunarli uslubda javob bering.`;

  const promptText = `
HOZIRGI MT5 BOZOR HOLATI:
- Aktiv: ${market.symbol} (${market.displayName})
- Taymfreym: ${market.timeframe}
- Joriy Narx: ${market.currentPrice.toFixed(2)} (Bid: ${market.bid.toFixed(2)}, Ask: ${market.ask.toFixed(2)})
- 24s O'zgarish: ${market.change24h > 0 ? '+' : ''}${market.change24h.toFixed(2)}%
- EMA 20: ${market.ema20.toFixed(2)}, EMA 50: ${market.ema50.toFixed(2)}
- RSI (14): ${market.rsi.toFixed(1)}
- Trend holati: ${market.trend}
- Oxirgi shamchalar (Candlesticks):
${recentCandlesText}

YUKLANGAN KITOB LAR VA STRATEGIYALAR:
${booksText}

FOYDALANUVCHI SAVOLI:
${userQuery || "Hozirgi MT5 grafigini kitoblarimdagi strategiyalar asosida tahlil qilib ber. Bozorda qanday imkoniyat bor, qayerdan kirish va chiqish kerak?"}
`;

  const parts: any[] = [];
  if (imageData && imageData.base64) {
    parts.push({
      inlineData: {
        data: imageData.base64,
        mimeType: imageData.mimeType || 'image/png',
      },
    });
  }
  parts.push({ text: promptText });

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: { parts },
    config: {
      systemInstruction,
      temperature: 0.4,
    },
  });

  return response.text || 'Tahlil yakunlanmadi. Iltimos qaytadan urinib ko\'ring.';
}

/**
 * Handle Real-Time Phone Call dialog with voice optimization
 */
export async function generatePhoneCallResponse({
  userSpeech,
  callHistory,
  market,
  books,
}: {
  userSpeech: string;
  callHistory: { role: 'user' | 'assistant'; text: string }[];
  market: MarketContextItem;
  books: BookContextItem[];
}) {
  const booksSummary = books.length > 0
    ? books.map(b => `"${b.name}": ${b.content.slice(0, 400)}...`).join('\n')
    : 'ICT, Wyckoff, Price Action kitoblari';

  const historyText = callHistory.slice(-6).map(h => `${h.role === 'user' ? 'Treydir' : 'MT5 AI Ustoz'}: ${h.text}`).join('\n');

  const systemInstruction = `Siz treyder bilan telefonda to'g'ridan-to'g'ri jonli qo'ng'iroqda gaplashayotgan tajribali MT5 AI ustozsiz.
Sizning ohangingiz: do'stona, xotirjam, professional, ishonchli va jonli suhbatdek tabiiy.

QO'NG'IROQ QOIDALARI:
- Telefonda gaplashayotgandek qisqa, aniq va jonli jumlalar bilan gapiring (uzun ro'yxatlar yoki murakkab formulalarni ovozda aytish noqulay, shuning uchun tushunarli qilib ayting).
- Treydir sizdan maslahat so'raganda uning yuklagan kitoblaridagi qoidalarni va hozirgi MT5 real vaqt grafigi holatini hisobga olib javob bering.
- Narx: ${market.symbol} ${market.currentPrice.toFixed(2)}, Trend: ${market.trend}, RSI: ${market.rsi.toFixed(0)}.
- Masalan: "Aha, Saidolim, hozir oltin grafigida narx 2882 da. Kitobingizdagi Order Block qoidasiga qarasak, 2878 da kuchli talab zonasi bor. Hozir shoshilmay, o'sha zonaga test berganda Buy ga kirishimiz xavfsizroq bo'ladi..."
- O'zbek tilida so'zlashuv ohangida gapiring.`;

  const promptText = `
SUHBAT TARIXI:
${historyText}

TREYDIRNING TELEFONDAGI HOZIRGI GAPI:
"${userSpeech}"

BOZOR MA'LUMOTI:
${market.symbol} narxi ${market.currentPrice.toFixed(2)}, EMA20: ${market.ema20.toFixed(2)}, EMA50: ${market.ema50.toFixed(2)}, RSI: ${market.rsi.toFixed(1)}

KITOB MANBALARI:
${booksSummary}

Javobingizni telefonda aytiladigan jonli ovozli nutq sifatida bering (belgilar, markdown yulduzchalari va jadvallarsiz, toza gaplar bilan).`;

  const response = await ai.models.generateContent({
    model: 'gemini-3.8-flash',
    contents: promptText,
    config: {
      systemInstruction,
      temperature: 0.6,
    },
  });

  return response.text || 'Ha, eshityapman. Hozirgi grafik bo\'yicha qanday savolingiz bor?';
}
