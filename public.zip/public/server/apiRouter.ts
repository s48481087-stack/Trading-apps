import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { analyzeMarketWithBooks, generatePhoneCallResponse, ai } from './geminiService.js';

export const apiRouter = express.Router();

apiRouter.use(express.json({ limit: '50mb' }));
apiRouter.use(express.urlencoded({ extended: true, limit: '50mb' }));

/**
 * Health check
 */
apiRouter.get('/health', (_req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

/**
 * Real-time Chart Analysis with active books
 */
apiRouter.post('/analyze-chart', async (req: Request, res: Response) => {
  try {
    const { market, books, userQuery, imageData } = req.body;
    if (!market) {
      return res.status(400).json({ error: 'Market data is required' });
    }

    const analysis = await analyzeMarketWithBooks({
      market,
      books: books || [],
      userQuery,
      imageData,
    });

    res.json({ success: true, analysis });
  } catch (error: any) {
    console.error('Error analyzing chart:', error);
    res.status(500).json({ error: error.message || 'Xatolik yuz berdi' });
  }
});

/**
 * Chat with Copilot using loaded books & market data
 */
apiRouter.post('/chat', async (req: Request, res: Response) => {
  try {
    const { message, chatHistory, market, books, image } = req.body;

    const booksContext = Array.isArray(books) && books.length > 0
      ? books.map((b: any) => `[KITOB: ${b.name}]\n${b.content}`).join('\n\n')
      : 'Standart texnik tahlil, Wyckoff, ICT va Price Action prinsiplari.';

    const marketContext = market
      ? `Aktiv: ${market.symbol}, Narx: ${market.currentPrice}, Trend: ${market.trend}, EMA20: ${market.ema20}, EMA50: ${market.ema50}, RSI: ${market.rsi}`
      : 'Aktiv ma\'lumoti mavjud emas';

    const systemInstruction = `Siz tajribali MT5 AI Trading Copilot va moliyaviy mentor-konsultantsiz.
Foydalanuvchining treyding kitoblari (SMC, Wyckoff, Price Action, Risk Management) va hozirgi MT5 bozor ma'lumotlari asosida to'liq, asosli va aniq javob bering.

QOIDALAR:
1. Javoblaringizda foydalanuvchi yuklagan kitob qoidalariga tayaning va aniq manbasini ayting.
2. Savol bozor narxiga oid bo'lsa, MT5 real vaqt ko'rsatkichlarini hisobga oling (${marketContext}).
3. Har doim risk menejmenti (1-2% dan oshmaslik, R:R kamida 1:2) haqida eslatib o'ting.
4. O'zbek tilida professional, tushunarli va do'stona tarzda javob qaytaring.
5. Kerak bo'lganda kirish nuqtasi (Entry), Stop Loss va Take Profit darajalarini tavsiya qiling.`;

    const parts: any[] = [];
    if (image && image.base64) {
      parts.push({
        inlineData: {
          data: image.base64,
          mimeType: image.mimeType || 'image/png',
        },
      });
    }

    const conversationHistory = Array.isArray(chatHistory)
      ? chatHistory.slice(-8).map((m: any) => `${m.sender === 'user' ? 'Treydir' : 'Copilot'}: ${m.text}`).join('\n')
      : '';

    const prompt = `
KITOB LAR VA QOIDALAR:
${booksContext}

JORIY MT5 BOZOR HOLATI:
${marketContext}

OLDINGI SUHBAT:
${conversationHistory}

FOYDALANUVCHI SAVOLI:
${message}
`;
    parts.push({ text: prompt });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        systemInstruction,
        temperature: 0.5,
      },
    });

    res.json({ success: true, text: response.text || '' });
  } catch (error: any) {
    console.error('Error in chat:', error);
    res.status(500).json({ error: error.message || 'Xatolik yuz berdi' });
  }
});

/**
 * Phone Call voice conversation response
 */
apiRouter.post('/phone-call', async (req: Request, res: Response) => {
  try {
    const { userSpeech, callHistory, market, books } = req.body;

    const responseText = await generatePhoneCallResponse({
      userSpeech: userSpeech || 'Salom, bozor bo\'yicha maslahat ber',
      callHistory: callHistory || [],
      market: market || {
        symbol: 'XAUUSD',
        displayName: 'Gold vs US Dollar',
        timeframe: 'H1',
        currentPrice: 2882.10,
        bid: 2882.10,
        ask: 2882.35,
        change24h: 0.82,
        high24h: 2895.0,
        low24h: 2865.0,
        ema20: 2834.69,
        ema50: 2811.41,
        rsi: 61.5,
        trend: 'UPTREND',
        recentCandles: [],
      },
      books: books || [],
    });

    res.json({ success: true, text: responseText });
  } catch (error: any) {
    console.error('Error in phone call:', error);
    res.status(500).json({ error: error.message || 'Ovozli javobda xatolik' });
  }
});

/**
 * Document extraction and AI summarization / rule extractor
 */
apiRouter.post('/parse-document', async (req: Request, res: Response) => {
  try {
    const { filename, textContent, imageBase64, mimeType } = req.body;

    const parts: any[] = [];
    if (imageBase64) {
      parts.push({
        inlineData: {
          data: imageBase64,
          mimeType: mimeType || 'image/png',
        },
      });
      parts.push({
        text: `Ushbu rasm treyding kitobi yoki MT5 grafik tahlili grafikasidir ("${filename}"). Rasmdagi shamchalar, indikatorlar, grafik paternlar, zonalar va asosiy treyding qoidalarini aniqlab, xulosani va o'rganilgan strategiya qoidalarini O'zbek tilida tuzib ber.`,
      });
    } else {
      parts.push({
        text: `Quyidagi yuklangan treyding hujjati matnini tahlil qiling ("${filename}"):
${textContent ? textContent.slice(0, 15000) : 'Matn berilmadi'}

Vazifa: Ushbu kitob/hujjatdan asosiy treyding strategiyalarini, kirish/chiqish qoidalarini, Risk menejment ko'rsatmalarini va muhim xulosalarni aniq punktlar shaklida o'zbek tilida ajratib ber. Keyinchalik AI bu qoidalar orqali foydalanuvchiga maslahat beradi.`,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: { parts },
      config: {
        systemInstruction: "Siz professional moliyaviy adabiyotlar va treyding strategiyalarini chuqur tahlil qiluvchi AI tizimsiz.",
        temperature: 0.3,
      },
    });

    res.json({ success: true, extractedSummary: response.text || '' });
  } catch (error: any) {
    console.error('Error parsing document:', error);
    res.status(500).json({ error: error.message || 'Hujjatni o\'rganishda xatolik' });
  }
});

/**
 * Export complete project source code for VS Code and APK build
 */
apiRouter.get('/export-files', (_req: Request, res: Response) => {
  try {
    const rootDir = process.cwd();
    const filesToInclude = [
      'package.json',
      'tsconfig.json',
      'vite.config.ts',
      'index.html',
      'metadata.json',
      'server.ts',
      'src/App.tsx',
      'src/main.tsx',
      'src/index.css',
      'src/types.ts',
      'src/components/Header.tsx',
      'src/components/ChartSection.tsx',
      'src/components/PhoneCallModal.tsx',
      'src/components/BooksLibrary.tsx',
      'src/components/CopilotChat.tsx',
      'src/components/TradingJournal.tsx',
      'src/components/VSCodeExportModal.tsx',
      'src/components/OrderPlacementModal.tsx',
      'src/data/defaultBooks.ts',
      'src/data/marketAssets.ts',
      'src/utils/indicators.ts',
      'src/utils/documentParser.ts',
      'server/geminiService.ts',
      'server/apiRouter.ts',
      'README.md',
    ];

    const result: { path: string; content: string }[] = [];

    for (const relPath of filesToInclude) {
      const fullPath = path.join(rootDir, relPath);
      if (fs.existsSync(fullPath)) {
        const content = fs.readFileSync(fullPath, 'utf8');
        result.push({ path: relPath, content });
      }
    }

    res.json({ success: true, files: result });
  } catch (error: any) {
    console.error('Error exporting files:', error);
    res.status(500).json({ error: 'Fayllarni eksport qilishda xatolik' });
  }
});