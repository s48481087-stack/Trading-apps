# MT5 AI Copilot - Kitoblar & Bozor Tahlili

Ushbu dastur treyding kitoblarini (PDF, Word DOC/DOCX, Excel XLS/XLSX, matn va diagramma rasmlari) tahlil qilib, ulardagi strategiyalarni real vaqt MT5 birja grafigi (XAUUSD, EURUSD, BTCUSD va h.k.) bilan bog'laydigan hamda telefon qo'ng'irog'i tarzida ovozli maslahat beradigan zamonaviy AI tizimdir.

## 🚀 VS Code dasturida ishga tushirish

1. Ushbu loyihani VS Code dasturida oching:
   - `File` -> `Open Folder...` -> Loyiha papkasini tanlang.
2. Terminalni oching (`Ctrl + \`` yoki `Terminal -> New Terminal`).
3. Kutubxonalarni o'rnating:
   ```bash
   npm install
   ```
4. Dasturni ishga tushiring:
   ```bash
   npm run dev
   ```
5. Brauzeringizda oching:
   ```
   http://localhost:3000
   ```

## 📱 Android APK yaratish

### 1-usul: Progressive Web App (PWA) - 1 daqiqada
- Loyiha havolasini telefoningizdagi **Google Chrome** orqali oching.
- Brauzer sozlamalari menyusi (uch nuqta `⋮`) ni bosing.
- **"Ilovani o'rnatish" (Install App / Add to Home screen)** ni bosing.
- Ilova telefoningizga APK formatida o'rnatiladi.

### 2-usul: Capacitor orqali haqiqiy `.apk` yig'ish:
```bash
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "MT5 AI Copilot" "com.mt5.aicopilot" --web-dir dist
npx cap add android
npx cap open android
```
So'ng Android Studio da `Build -> Build Bundle(s) / APK(s) -> Build APK(s)` bosiladi.

---
Yaratuvchi: Saidolim
Texnologiyalar: React 19, TypeScript, Tailwind CSS, Google Gemini 3.8 Flash, Vite, Express, Web Speech API, MT5 Canvas Engine.
