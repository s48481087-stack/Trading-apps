export type Timeframe = 'M1' | 'M5' | 'M15' | 'M30' | 'H1' | 'H4' | 'D1';

export interface Candle {
  time: string;
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface MarketAsset {
  symbol: string;
  displayName: string;
  category: 'Forex' | 'Metals' | 'Crypto' | 'Indices';
  decimals: number;
  currentPrice: number;
  bid: number;
  ask: number;
  spread: number;
  change24h: number;
  high24h: number;
  low24h: number;
  volume24h: string;
  trend: 'UPTREND' | 'DOWNTREND' | 'SIDEWAYS';
}

export interface BookItem {
  id: string;
  title: string;
  author: string;
  category: string;
  format: 'pdf' | 'docx' | 'xlsx' | 'image' | 'text';
  size: string;
  pagesCount?: number;
  content: string;
  summary: string;
  rules: string[];
  imagePreview?: string;
  isPreloaded?: boolean;
  isEnabled: boolean;
  dateAdded: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  citedBooks?: string[];
  chartSnapshot?: {
    symbol: string;
    price: number;
    timeframe: string;
  };
  imageAttachment?: string;
  signalRecommendation?: {
    type: 'BUY' | 'SELL' | 'WAIT';
    entry: number;
    sl: number;
    tp: number;
    riskReward: string;
  };
}

export interface TradePosition {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL';
  openPrice: number;
  currentPrice: number;
  sl?: number;
  tp?: number;
  lots: number;
  openTime: string;
  pnl: number;
  status: 'OPEN' | 'CLOSED';
  closePrice?: number;
  closeTime?: string;
  strategyNote?: string;
}

export interface IndicatorSettings {
  showEma20: boolean;
  showEma50: boolean;
  showVolume: boolean;
  showRsi: boolean;
  showOrderBlocks: boolean;
}

export interface PhoneCallState {
  isOpen: boolean;
  status: 'idle' | 'dialing' | 'connected' | 'speaking' | 'listening' | 'ended';
  durationSeconds: number;
  isMuted: boolean;
  isSpeakerOn: boolean;
  history: { role: 'user' | 'assistant'; text: string; timestamp?: string }[];
}
