import { Candle } from '../types.js';

/**
 * Calculate Exponential Moving Average (EMA)
 */
export function calculateEMA(candles: Candle[], period: number): number[] {
  if (candles.length === 0) return [];
  const k = 2 / (period + 1);
  const emaValues: number[] = [];

  // Start with simple average for first 'period' elements
  let sum = 0;
  const initialPeriod = Math.min(period, candles.length);
  for (let i = 0; i < initialPeriod; i++) {
    sum += candles[i].close;
  }
  let currentEma = sum / initialPeriod;
  emaValues.push(currentEma);

  for (let i = initialPeriod; i < candles.length; i++) {
    currentEma = candles[i].close * k + currentEma * (1 - k);
    emaValues.push(currentEma);
  }

  // Prepend padding with null or initial values so length matches candles
  const paddingCount = candles.length - emaValues.length;
  const result: number[] = [];
  for (let i = 0; i < paddingCount; i++) {
    result.push(candles[i].close);
  }
  return [...result, ...emaValues];
}

/**
 * Calculate Relative Strength Index (RSI 14)
 */
export function calculateRSI(candles: Candle[], period = 14): number {
  if (candles.length <= period) return 50;

  let gains = 0;
  let losses = 0;

  for (let i = candles.length - period; i < candles.length; i++) {
    const diff = candles[i].close - candles[i - 1].close;
    if (diff >= 0) {
      gains += diff;
    } else {
      losses += Math.abs(diff);
    }
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  const rsi = 100 - (100 / (1 + rs));
  return Number(rsi.toFixed(1));
}

/**
 * Identify Key Order Blocks & Support / Resistance levels
 */
export function identifyOrderBlocks(candles: Candle[]) {
  if (candles.length < 10) return { bullishOB: null, bearishOB: null, support: 0, resistance: 0 };

  const recent = candles.slice(-30);
  const highest = Math.max(...recent.map(c => c.high));
  const lowest = Math.min(...recent.map(c => c.low));

  // Find lowest candle before significant up move
  let lowestCandle = recent[0];
  let highestCandle = recent[0];

  for (const c of recent) {
    if (c.low < lowestCandle.low) lowestCandle = c;
    if (c.high > highestCandle.high) highestCandle = c;
  }

  return {
    bullishOB: {
      high: lowestCandle.open,
      low: lowestCandle.low,
      label: 'Bullish OB (Talab)',
    },
    bearishOB: {
      high: highestCandle.high,
      low: highestCandle.open,
      label: 'Bearish OB (Taklif)',
    },
    support: lowest,
    resistance: highest,
  };
}
