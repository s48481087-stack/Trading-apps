import { MarketAsset, Candle, Timeframe } from '../types.js';

export const INITIAL_ASSETS: MarketAsset[] = [
  {
    symbol: 'XAUUSD',
    displayName: 'Gold vs US Dollar',
    category: 'Metals',
    decimals: 2,
    currentPrice: 2882.10,
    bid: 2882.10,
    ask: 2882.35,
    spread: 0.25,
    change24h: 0.82,
    high24h: 2898.40,
    low24h: 2862.15,
    volume24h: '42.8K Lots',
    trend: 'UPTREND',
  },
  {
    symbol: 'EURUSD',
    displayName: 'Euro vs US Dollar',
    category: 'Forex',
    decimals: 5,
    currentPrice: 1.08420,
    bid: 1.08420,
    ask: 1.08432,
    spread: 0.00012,
    change24h: -0.18,
    high24h: 1.08850,
    low24h: 1.08210,
    volume24h: '128.4K Lots',
    trend: 'SIDEWAYS',
  },
  {
    symbol: 'GBPUSD',
    displayName: 'Great Britain Pound vs US Dollar',
    category: 'Forex',
    decimals: 5,
    currentPrice: 1.29450,
    bid: 1.29450,
    ask: 1.29465,
    spread: 0.00015,
    change24h: 0.35,
    high24h: 1.29900,
    low24h: 1.28950,
    volume24h: '85.2K Lots',
    trend: 'UPTREND',
  },
  {
    symbol: 'BTCUSD',
    displayName: 'Bitcoin vs US Dollar',
    category: 'Crypto',
    decimals: 2,
    currentPrice: 92450.00,
    bid: 92450.00,
    ask: 92475.00,
    spread: 25.0,
    change24h: 2.45,
    high24h: 93800.00,
    low24h: 89900.00,
    volume24h: '18.9K BTC',
    trend: 'UPTREND',
  },
  {
    symbol: 'US30',
    displayName: 'Dow Jones Industrial 30',
    category: 'Indices',
    decimals: 1,
    currentPrice: 43820.5,
    bid: 43820.5,
    ask: 43823.5,
    spread: 3.0,
    change24h: 0.54,
    high24h: 44100.0,
    low24h: 43650.0,
    volume24h: '25.4K Lots',
    trend: 'UPTREND',
  },
  {
    symbol: 'NAS100',
    displayName: 'US Tech 100 Index',
    category: 'Indices',
    decimals: 1,
    currentPrice: 20950.2,
    bid: 20950.2,
    ask: 20952.8,
    spread: 2.6,
    change24h: 1.15,
    high24h: 21120.0,
    low24h: 20740.0,
    volume24h: '36.1K Lots',
    trend: 'UPTREND',
  },
  {
    symbol: 'USDJPY',
    displayName: 'US Dollar vs Japanese Yen',
    category: 'Forex',
    decimals: 3,
    currentPrice: 153.420,
    bid: 153.420,
    ask: 153.435,
    spread: 0.015,
    change24h: -0.42,
    high24h: 154.200,
    low24h: 152.950,
    volume24h: '64.0K Lots',
    trend: 'DOWNTREND',
  },
];

/**
 * Generate realistic candlestick history matching MT5 look
 */
export function generateCandlestickHistory(symbol: string, _timeframe: Timeframe, count = 75): Candle[] {
  const asset = INITIAL_ASSETS.find(a => a.symbol === symbol) || INITIAL_ASSETS[0];
  const targetEndPrice = asset.currentPrice;
  const candles: Candle[] = [];

  // Volatility scale
  const volatility = symbol === 'BTCUSD' ? 350 : symbol.includes('USD') && !symbol.includes('JPY') && symbol !== 'XAUUSD' ? 0.0015 : symbol === 'XAUUSD' ? 6.5 : 45;

  let currentClose = targetEndPrice - (volatility * count * 0.15); // start lower for uptrend
  const now = Date.now();
  const timeStepMs = 60 * 60 * 1000; // 1 hour step

  for (let i = 0; i < count; i++) {
    const timestamp = now - ((count - i) * timeStepMs);
    const date = new Date(timestamp);
    const time = `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}`;

    const trendBias = (i / count) * 0.4; // general upward curve matching screenshot
    const change = (Math.random() - 0.45 + trendBias) * volatility;
    const open = currentClose;
    let close = open + change;

    // Last candle closes exactly at current price
    if (i === count - 1) {
      close = targetEndPrice;
    }

    const high = Math.max(open, close) + Math.random() * (volatility * 0.7);
    const low = Math.min(open, close) - Math.random() * (volatility * 0.7);
    const volume = Math.floor(Math.random() * 450) + 120;

    candles.push({
      time,
      timestamp,
      open: Number(open.toFixed(asset.decimals)),
      high: Number(high.toFixed(asset.decimals)),
      low: Number(low.toFixed(asset.decimals)),
      close: Number(close.toFixed(asset.decimals)),
      volume,
    });

    currentClose = close;
  }

  return candles;
}
