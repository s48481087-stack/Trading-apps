import { BookItem } from '../types.js';

export const DEFAULT_TRADING_BOOKS: BookItem[] = [
  {
    id: 'book-smc-ict',
    title: 'Smart Money Concepts & ICT Trading Manual',
    author: 'Michael J. Huddleston (ICT)',
    category: 'Smart Money Concepts (SMC)',
    format: 'pdf',
    size: '4.8 MB',
    pagesCount: 184,
    isEnabled: true,
    isPreloaded: true,
    dateAdded: '2026-10-01',
    summary: 'Banklar va yirik institutlar (Smart Money) qanday iz qoldirishini tushunish, Order Block (OB), Fair Value Gap (FVG) va likvidlik ovlash (Liquidity Sweeps) strategiyasi.',
    rules: [
      'Order Block (OB): Katta harakat oldidan teskari yo\'nalishda yopilgan oxirgi institutsional shamcha. Narx ushbu zonaga qaytganda kirish amalga oshiriladi.',
      'Fair Value Gap (FVG): 3 ta ketma-ket shamcha orasidagi nomutanosiblik (imbalance). Narx FVG ni to\'ldirish uchun qaytadi (Rebalance).',
      'Liquidity Run: Oldingi High va Low nuqtalardagi chakana treyderlarning Stop Losslari yechib olingandan so\'ng (Buy-side/Sell-side liquidity sweep), bozor haqiqiy yo\'nalishga buriladi.',
      'Market Structure Shift (MSS): Trendning sinishi va yangi yuqori cho\'qqi (HH) yoki pastki cho\'qqi (LL) hosil bo\'lishi.',
      'Optimal Trade Entry (OTE): Fibonacci 61.8% - 78.6% darajalaridagi kirish nuqtalari eng yuqori ehtimolli setup hisoblanadi.',
    ],
    content: `SMART MONEY CONCEPTS (SMC) VA ICT TREYDING STRATEGIYASI:
1. Institutsional likvidlik: Chakana treyderlar odatda qo'llab-quvvatlash va qarshilik (Support/Resistance) darajalarining orqasiga Stop Loss qo'yadilar. Banklar (Smart Money) narxni shu darajalardan oshirib, likvidlikni to'playdi (Liquidity Sweep) va so'ng teskari harakatni boshlaydi.
2. Order Block aniqlash: Agar narx kuchli ko'tarilsa, ko'tarilishdan oldingi oxirgi qizil (bearish) shamcha Bullish Order Block (talab zonasi) hisoblanadi. Narx unga qaytganda Buy bitimi ochiladi. SL bu Order Blockning eng quyi nuqtasidan 3-5 pip pastga qo'yiladi.
3. Fair Value Gap (FVG): Birinchi shamchaning soyasi va uchinchi shamchaning soyasi o'rtasida bo'shliq qolgan bo'lsa, bu FVG. Narx ushbu bo'shliqning 50% (Consequent Encroachment) yoki to'liq qismiga qaytganida kirish mumkin.
4. Risk-Reward nisbati: SMC dagi har qanday bitim kamida 1:3 yoki 1:4 R:R nisbatiga ega bo'lishi shart.`,
  },
  {
    id: 'book-wyckoff-vsa',
    title: 'The Wyckoff Method & Volume Spread Analysis',
    author: 'Richard D. Wyckoff',
    category: 'Volume Spread Analysis (VSA)',
    format: 'pdf',
    size: '6.2 MB',
    pagesCount: 220,
    isEnabled: true,
    isPreloaded: true,
    dateAdded: '2026-09-28',
    summary: 'Bozorning to\'rt fazasi: Jamg\'arish (Accumulation), Ko\'tarilish (Markup), Taqsimot (Distribution), Pasayish (Markdown) hamda hajm (Volume) orqali yirik ishtirokchilarni fosh qilish.',
    rules: [
      'Bozor sikllari: Accumulation -> Markup -> Distribution -> Markdown.',
      'Spring (Prujina): Qo\'llab-quvvatlash darajasini vaqtincha buzib tushish (false breakout) va keyin kuchli hajm bilan tezda diapazonga qaytish - eng kuchli BUY signali.',
      'Upthrust (UTAD): Qarshilik darajasidan yuqoriga yolg\'on sakrash va hajm bilan pastga qaytish - eng kuchli SELL signali.',
      'Effort vs Result: Katta hajm (Volume) bo\'lib narx harakatlanmasa, teskari tomonga burilish yaqinlashmoqda.',
      'Sign of Strength (SOS): Katta yashil shamcha bilan qarshilikni yorib o\'tish va past hajm bilan unga test berish (LPS).',
    ],
    content: `WYCKOFF USLUBI VA HAJM TAHLILI (VSA):
Richard Wyckoff qoidalariga ko'ra bozor tasodifiy harakatlanmaydi, uni "Composite Man" (birlashgan yirik sarmoyadorlar) boshqaradi.
1. Accumulation (Jamg'arish fazasi): Narx ma'lum bir tor yo'lakda (Trading Range) harakatlanadi. Pastki nuqtada Spring (tuzoq) hosil qilib chakana sotuvchilarni sarosimaga soladi. Keyin narx yo'lakdan yuqoriga chiqadi (Sign of Strength - SOS).
2. Test qilish: Har qanday yorib o'tishdan keyin past hajmda (Low volume) qayta tekshirish (Test) kutiladi. Bu xavfsiz kirish nuqtasi hisoblanadi.
3. Hajm tahlili: Narx ko'tarilayotganda hajm ham oshsa - bu sog'lom trend. Agar narx oshib, hajm kamaysa - xaridorlar kuchi tugamoqda, burilish kutiladi.`,
  },
  {
    id: 'book-price-action-bible',
    title: 'The Candlestick Trading Bible & Price Action',
    author: 'Munehisa Homma & Al Brooks',
    category: 'Price Action & Candlesticks',
    format: 'docx',
    size: '3.5 MB',
    pagesCount: 165,
    isEnabled: true,
    isPreloaded: true,
    dateAdded: '2026-09-20',
    summary: 'Yapon shamchalari sirlari, Pin bar, Engulfing (yutib yuboruvchi), Morning Star, ichki shamchalar (Inside Bar) va dinamik harakatlanuvchi o\'rtachalar (EMA 20/50).',
    rules: [
      'Pin Bar Rejection: Uzun dumi asosiy darajaga tegib qaytgan shamcha kuchli burilishdan dalolat beradi.',
      'Bullish / Bearish Engulfing: Oldingi shamchaning butun tanasini qoplagan katta shamcha kuch balansining almashganini ko\'rsatadi.',
      'EMA 20 & EMA 50 Dinamik Trend: EMA 20 EMA 50 dan yuqorida bo\'lsa (Golden Cross) - faqat Buy qidiriladi. Narx EMA 20 ga tekkanda sakrash (pullback) olinadi.',
      'Confluence (Qo\'shilish nuqtasi): Bir vaqtning o\'zida shamcha signali + EMA darajasi + gorizontal Support to\'g\'ri kelgan joy eng yuqori ehtimolli bitimdir.',
    ],
    content: `PRICE ACTION VA YAPON SHAMCHALARI QOIDALARI:
- Pin Bar: Tanasining hajmi shamchaning umumiy uzunligining uchdan biridan (1/3) kam bo'lishi, dumi esa 2/3 qismini tashkil qilishi shart. Dumi qayerga yo'naltirilgan bo'lsa, narx unga qarama-qarshi tomonga harakatlanadi.
- Trend bilan savdo: Doimo EMA 20 va EMA 50 yo'nalishida savdo qiling. Hech qachon kuchli trendga qarshi kirmang.
- Kirish taktikasi: Signal shamchasi yopilgandan so'ng keyingi shamchada kirish, Stop Lossni signal shamchasi ekstremumidan nariga qo'yish.`,
  },
  {
    id: 'book-risk-management',
    title: 'Professional Risk & Money Management Guide',
    author: 'Mark Douglas (Trading in the Zone)',
    category: 'Risk & Money Management',
    format: 'xlsx',
    size: '1.2 MB',
    pagesCount: 88,
    isEnabled: true,
    isPreloaded: true,
    dateAdded: '2026-09-15',
    summary: 'Kapitalni saqlash, har bir bitimda hisobning 1-2% idan oshmaslik, lot hajmini avtomatik hisoblash, Drawdown boshqaruvi va 1:2.5+ R:R qat\'iy qoidalari.',
    rules: [
      '1% Qoidasi: Hech qachon bir bitimda depozitning 1% yoki 2% idan ko\'p yo\'qotmang.',
      'Lot hisoblash: Lot = (Depozit * Risk %) / (Stop Loss pips * Pip qiymati). Masalan: $10,000 hisobda 1% ($100) risk bilan 20 pip SL uchun lot hajmi = 0.5 lot.',
      'Risk-to-Reward: Kamida 1:2 yoki 1:3 nisbat bo\'lmagan setup ga aslo kirmaslik.',
      'Breakeven qoidasi: Narx 1:1 masofani bosib o\'tganda Stop Lossni kirish narxiga (Entry) ko\'chirish.',
      'Kunlik limit: Agar kuniga 3% zarar ko\'rilsa, o\'sha kungi savdoni darhol to\'xtatish.',
    ],
    content: `RISK MENEJMENT VA PSIXOLOGIYA METODIKASI:
Muvaffaqiyatli treyderning siri 90% risk menejmentida.
1. Bitim hajmini to'g'ri tanlash hisobni margin call dan saqlaydi.
2. Pozitsiyani bo'lib yopish: TP1 da (1:1.5 R:R) pozitsiyaning 50% ini yopib, qolganini Breakeven ga qo'yib TP2 (1:3 R:R) gacha ushlab turish.
3. Hissiyotlarni chetga surish: Har bir bitim faqat qoidalarga to'g'ri kelgandagina ochiladi.`,
  },
];
