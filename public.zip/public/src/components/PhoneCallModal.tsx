import React, { useState, useEffect, useRef } from 'react';
import { PhoneOff, Mic, MicOff, Volume2, VolumeX, Sparkles, User, Bot, HelpCircle, Activity } from 'lucide-react';
import { MarketAsset, BookItem } from '../types.js';

interface PhoneCallModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeAsset: MarketAsset;
  activeBooks: BookItem[];
}

export const PhoneCallModal: React.FC<PhoneCallModalProps> = ({
  isOpen,
  onClose,
  activeAsset,
  activeBooks,
}) => {
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [callStatus, setCallStatus] = useState<'connecting' | 'listening' | 'thinking' | 'speaking'>('connecting');
  const [transcriptHistory, setTranscriptHistory] = useState<{ role: 'user' | 'assistant'; text: string; time: string }[]>([]);
  const [currentInputText, setCurrentInputText] = useState('');
  const [isListeningSpeech, setIsListeningSpeech] = useState(false);

  const recognitionRef = useRef<any>(null);
  const timerRef = useRef<any>(null);
  const historyEndRef = useRef<HTMLDivElement | null>(null);

  // Auto scroll transcript to bottom
  useEffect(() => {
    historyEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcriptHistory, callStatus]);

  // Speech Recognition & Call setup
  useEffect(() => {
    if (!isOpen) {
      if (timerRef.current) clearInterval(timerRef.current);
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      setCallDuration(0);
      setTranscriptHistory([]);
      return;
    }

    // Call connected simulation
    setCallStatus('connecting');
    const connectTimer = setTimeout(() => {
      setCallStatus('speaking');
      const greeting = `Assalomu alaykum! Men sizning MT5 AI treyding ustozingizman. Hozirgi ${activeAsset.symbol} grafigi (${activeAsset.currentPrice.toFixed(activeAsset.decimals)}) va yuklangan ${activeBooks.length} ta kitobingiz bo'yicha sizni eshityapman. Qanday savolingiz bor?`;
      
      setTranscriptHistory([
        {
          role: 'assistant',
          text: greeting,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakText(greeting);
    }, 1200);

    // Call duration timer
    timerRef.current = setInterval(() => {
      setCallDuration(prev => prev + 1);
    }, 1000);

    // Initialize Web Speech Recognition if available
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'uz-UZ';

      recognition.onresult = (event: any) => {
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            const finalSpeech = event.results[i][0].transcript.trim();
            if (finalSpeech) {
              handleUserSpeech(finalSpeech);
            }
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        if (interim) {
          setCurrentInputText(interim);
        }
      };

      recognition.onerror = (e: any) => {
        console.warn('Speech recognition event:', e.error);
        setIsListeningSpeech(false);
      };

      recognition.onend = () => {
        setIsListeningSpeech(false);
      };

      recognitionRef.current = recognition;
    }

    return () => {
      clearTimeout(connectTimer);
      if (timerRef.current) clearInterval(timerRef.current);
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      window.speechSynthesis?.cancel();
    };
  }, [isOpen]);

  // Toggle listening to speech
  const toggleListening = () => {
    if (isListeningSpeech) {
      if (recognitionRef.current) {
        try { recognitionRef.current.stop(); } catch (e) {}
      }
      setIsListeningSpeech(false);
      setCallStatus('speaking');
    } else {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.start();
          setIsListeningSpeech(true);
          setCallStatus('listening');
        } catch (e) {
          console.error(e);
        }
      }
    }
  };

  // Speak text via browser SpeechSynthesis
  const speakText = (text: string) => {
    if (!isSpeakerOn || typeof window === 'undefined' || !window.speechSynthesis) {
      setCallStatus('listening');
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown characters for voice
    const cleanText = text.replace(/[*#_`>]/g, '').slice(0, 400);
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    // Check for Uzbek / Russian / English voices
    const voices = window.speechSynthesis.getVoices();
    const uzVoice = voices.find(v => v.lang.includes('uz') || v.lang.includes('tr') || v.lang.includes('ru'));
    if (uzVoice) utterance.voice = uzVoice;

    utterance.onstart = () => setCallStatus('speaking');
    utterance.onend = () => setCallStatus('listening');
    utterance.onerror = () => setCallStatus('listening');

    window.speechSynthesis.speak(utterance);
  };

  // Handle user speech question
  const handleUserSpeech = async (speechText: string) => {
    if (!speechText.trim()) return;

    setCurrentInputText('');
    setTranscriptHistory(prev => [
      ...prev,
      {
        role: 'user',
        text: speechText,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    setCallStatus('thinking');

    try {
      const response = await fetch('/api/phone-call', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userSpeech: speechText,
          callHistory: transcriptHistory.slice(-5),
          market: {
            symbol: activeAsset.symbol,
            displayName: activeAsset.displayName,
            currentPrice: activeAsset.currentPrice,
            bid: activeAsset.bid,
            ask: activeAsset.ask,
            trend: activeAsset.trend,
            change24h: activeAsset.change24h,
            ema20: activeAsset.currentPrice * 0.992,
            ema50: activeAsset.currentPrice * 0.985,
            rsi: 61.5,
          },
          books: activeBooks.map(b => ({
            id: b.id,
            name: b.title,
            category: b.category,
            content: b.content,
            rules: b.rules,
          })),
        }),
      });

      const data = await response.json();
      const reply = data.text || 'Ha, eshityapman. Qoidalarimiz bo\'yicha bozor holatini kuzatyapmiz.';

      setTranscriptHistory(prev => [
        ...prev,
        {
          role: 'assistant',
          text: reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);

      speakText(reply);
    } catch (err: any) {
      console.error('Call failed:', err);
      const fallbackReply = 'Internet aloqasi sekinlashdi, ammo kitobingizdagi risk menejmenti qoidasiga ko\'ra 1% dan ortiq xavf qilmang.';
      setTranscriptHistory(prev => [
        ...prev,
        {
          role: 'assistant',
          text: fallbackReply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      speakText(fallbackReply);
    }
  };

  // Format seconds to mm:ss
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      {/* Smartphone Phone Call Screen */}
      <div className="w-full max-w-md bg-[#0a0f1c] rounded-3xl border border-slate-700/80 shadow-2xl overflow-hidden flex flex-col h-[90vh] max-h-[720px] relative">
        {/* Call Top Header */}
        <div className="bg-gradient-to-b from-[#131b2e] to-[#0a0f1c] pt-6 pb-4 px-6 text-center border-b border-slate-800 flex flex-col items-center">
          {/* Pulsing Avatar */}
          <div className="relative mb-3">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-xl shadow-cyan-500/30 text-white">
              <Bot className="w-10 h-10" />
            </div>
            {callStatus === 'speaking' && (
              <span className="absolute -inset-1.5 rounded-full border-2 border-emerald-400 animate-ping opacity-60"></span>
            )}
            {callStatus === 'listening' && (
              <span className="absolute -inset-1.5 rounded-full border-2 border-cyan-400 animate-pulse"></span>
            )}
          </div>

          <h2 className="text-xl font-extrabold text-white tracking-wide">
            MT5 AI Ustoz & Treyding Mentor
          </h2>

          <div className="flex items-center gap-2 text-xs mt-1">
            <span className="flex items-center gap-1 text-emerald-400 font-mono font-semibold">
              <Activity className="w-3.5 h-3.5 animate-pulse" />
              {callStatus === 'connecting' && 'Ulanmoqda...'}
              {callStatus === 'speaking' && 'AI gapirmoqda...'}
              {callStatus === 'listening' && 'Sizni eshitmoqda...'}
              {callStatus === 'thinking' && 'Kitoblar va MT5 tahlil qilinmoqda...'}
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-300 font-mono font-bold bg-slate-800/80 px-2 py-0.5 rounded-full">
              {formatTime(callDuration)}
            </span>
          </div>

          {/* Market & Books active pill */}
          <div className="mt-2.5 inline-flex items-center gap-2 bg-[#141d2f] px-3 py-1 rounded-full border border-slate-700/60 text-[11px] text-slate-300">
            <span className="text-cyan-400 font-bold">{activeAsset.symbol}: ${activeAsset.currentPrice.toFixed(activeAsset.decimals)}</span>
            <span className="text-slate-600">|</span>
            <span className="text-amber-300">{activeBooks.length} ta kitob ulangan</span>
          </div>
        </div>

        {/* Dynamic Audio Visualizer Waves */}
        <div className="h-12 bg-[#090d17] flex items-center justify-center gap-1 px-8 border-b border-slate-800/60">
          {[...Array(18)].map((_, i) => (
            <div
              key={i}
              className={`w-1 rounded-full transition-all duration-150 ${
                callStatus === 'speaking'
                  ? 'bg-emerald-400 animate-pulse'
                  : callStatus === 'listening'
                  ? 'bg-cyan-400'
                  : 'bg-slate-700'
              }`}
              style={{
                height: callStatus === 'speaking'
                  ? `${Math.max(6, Math.sin(i * 0.5 + callDuration * 3) * 28 + 12)}px`
                  : callStatus === 'listening'
                  ? `${Math.max(4, Math.cos(i * 0.4) * 16 + 8)}px`
                  : '4px',
              }}
            />
          ))}
        </div>

        {/* Call Transcript Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 scrollbar-thin text-xs sm:text-sm">
          {transcriptHistory.map((item, idx) => (
            <div
              key={idx}
              className={`flex flex-col ${item.role === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1 px-1">
                {item.role === 'user' ? (
                  <><span>Siz</span> <User className="w-3 h-3 text-cyan-400" /></>
                ) : (
                  <><Bot className="w-3 h-3 text-emerald-400" /> <span>MT5 AI Ustoz</span></>
                )}
                <span>{item.time}</span>
              </div>
              <div
                className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed ${
                  item.role === 'user'
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-none shadow-md'
                    : 'bg-[#151d30] text-slate-200 border border-slate-800 rounded-bl-none shadow-md'
                }`}
              >
                {item.text}
              </div>
            </div>
          ))}

          {currentInputText && (
            <div className="flex flex-col items-end">
              <div className="text-[10px] text-cyan-400 italic mb-1">Eshitilmoqda...</div>
              <div className="max-w-[85%] bg-cyan-900/40 border border-cyan-500/40 text-cyan-200 rounded-2xl rounded-br-none px-3 py-2 italic text-xs">
                {currentInputText}
              </div>
            </div>
          )}

          {callStatus === 'thinking' && (
            <div className="flex items-center gap-2 text-cyan-400 italic text-xs bg-[#12192b] p-2.5 rounded-xl border border-slate-800">
              <Sparkles className="w-4 h-4 animate-spin text-cyan-400" />
              Kitoblar qoidalari va MT5 grafigi tekshirilmoqda...
            </div>
          )}

          <div ref={historyEndRef} />
        </div>

        {/* Quick Voice Questions Chips */}
        <div className="px-3 py-2 bg-[#0c1220] border-t border-slate-800/80 overflow-x-auto whitespace-nowrap scrollbar-none flex items-center gap-2 text-[11px]">
          <span className="text-slate-500 text-[10px] font-semibold flex items-center gap-1">
            <HelpCircle className="w-3 h-3 text-cyan-400" /> Tezkor savollar:
          </span>
          <button
            onClick={() => handleUserSpeech(`Hozirgi ${activeAsset.symbol} grafigida qanday imkoniyat bor? Kitob qoidalariga binoan tahlil ber.`)}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-full border border-slate-700 cursor-pointer active:scale-95 transition-all"
          >
            📊 {activeAsset.symbol} hozirgi holati?
          </button>
          <button
            onClick={() => handleUserSpeech('Kitobimdagi Order Block va Fair Value Gap bo\'yicha qayerdan kirish kerak?')}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-full border border-slate-700 cursor-pointer active:scale-95 transition-all"
          >
            🎯 Order Block qayerda?
          </button>
          <button
            onClick={() => handleUserSpeech('Risk menejmenti bo\'yicha Stop Loss va Take Profit qayerga qo\'yiladi?')}
            className="bg-slate-800/90 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-full border border-slate-700 cursor-pointer active:scale-95 transition-all"
          >
            🛡️ Stop Loss qayerda?
          </button>
        </div>

        {/* Phone Call Control Panel matching smartphone calling screen */}
        <div className="bg-[#0b101d] px-6 py-4 border-t border-slate-800/90 flex flex-col gap-3">
          {/* Text input fallback for typing during call */}
          <div className="flex items-center gap-2">
            <input
              type="text"
              value={currentInputText}
              onChange={(e) => setCurrentInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && currentInputText.trim()) {
                  handleUserSpeech(currentInputText.trim());
                }
              }}
              placeholder="Ovoz bilan yoki bu yerga yozib so'rang..."
              className="flex-1 bg-[#141b2c] border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
            {currentInputText.trim() && (
              <button
                onClick={() => handleUserSpeech(currentInputText.trim())}
                className="bg-cyan-500 text-slate-950 font-bold px-3 py-2 rounded-xl text-xs cursor-pointer hover:bg-cyan-400"
              >
                Yuborish
              </button>
            )}
          </div>

          {/* Main Calling Buttons */}
          <div className="flex items-center justify-around">
            {/* Mic Mute / Speech button */}
            <button
              onClick={toggleListening}
              className={`w-13 h-13 rounded-full flex flex-col items-center justify-center transition-all cursor-pointer shadow-lg active:scale-90 ${
                isListeningSpeech
                  ? 'bg-cyan-500 text-slate-950 ring-4 ring-cyan-500/40 animate-pulse'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
              title={isListeningSpeech ? "Mikrofonni to'xtatish" : "Mikrofonni yoqish"}
            >
              {isListeningSpeech ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              <span className="text-[9px] mt-0.5">{isListeningSpeech ? 'Yozmoqda' : 'Ovoz'}</span>
            </button>

            {/* End Call Button (Big Red Button) */}
            <button
              onClick={onClose}
              className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-500 text-white flex flex-col items-center justify-center shadow-xl shadow-rose-600/40 active:scale-90 transition-all cursor-pointer"
              title="Qo'ng'iroqni tugatish"
            >
              <PhoneOff className="w-7 h-7" />
              <span className="text-[9px] mt-0.5 font-bold uppercase tracking-wider">Tugatish</span>
            </button>

            {/* Speakerphone Toggle */}
            <button
              onClick={() => {
                setIsSpeakerOn(!isSpeakerOn);
                if (isSpeakerOn) window.speechSynthesis?.cancel();
              }}
              className={`w-13 h-13 rounded-full flex flex-col items-center justify-center transition-all cursor-pointer shadow-lg active:scale-90 ${
                isSpeakerOn
                  ? 'bg-slate-800 text-emerald-400 hover:bg-slate-700'
                  : 'bg-slate-800 text-slate-500 hover:bg-slate-700'
              }`}
              title={isSpeakerOn ? "Karnay yoqilgan" : "Karnay o'chirilgan"}
            >
              {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              <span className="text-[9px] mt-0.5">{isSpeakerOn ? 'Karnay' : 'Ovozsiz'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
