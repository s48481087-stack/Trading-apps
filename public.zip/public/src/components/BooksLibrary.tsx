import React, { useState } from 'react';
import { Upload, BookOpen, FileText, Image as ImageIcon, Table, Check, Trash2, Eye, Sparkles, Filter, Plus, ShieldCheck, ArrowRight } from 'lucide-react';
import { BookItem } from '../types.js';
import { parseUploadedFile } from '../utils/documentParser.js';

interface BooksLibraryProps {
  books: BookItem[];
  onToggleBook: (id: string) => void;
  onAddBook: (book: BookItem) => void;
  onDeleteBook: (id: string) => void;
  onSelectForChat: (book: BookItem) => void;
}

export const BooksLibrary: React.FC<BooksLibraryProps> = ({
  books,
  onToggleBook,
  onAddBook,
  onDeleteBook,
  onSelectForChat,
}) => {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [selectedBookForView, setSelectedBookForView] = useState<BookItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');

  // Handle file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    setUploadError(null);

    try {
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const parsed = await parseUploadedFile(file);

        // Call backend to analyze document & extract trading rules
        let extractedSummary = '';
        try {
          const resp = await fetch('/api/parse-document', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              filename: file.name,
              textContent: parsed.text.slice(0, 15000),
              imageBase64: parsed.imagePreview,
              mimeType: file.type,
            }),
          });
          const data = await resp.json();
          extractedSummary = data.extractedSummary || '';
        } catch (err) {
          console.warn('Backend parsing fallback', err);
          extractedSummary = `Ushbu ${parsed.format.toUpperCase()} hujjati muvaffaqiyatli indekslandi. Undagi asosiy treyding qoidalari va mazmuni AI xotirasiga kiritildi.`;
        }

        const newBook: BookItem = {
          id: `book-${Date.now()}-${i}`,
          title: file.name.replace(/\.[^/.]+$/, ''),
          author: parsed.format === 'image' ? 'Grafik Diagrammasi' : 'Yuklangan Muallif',
          category: parsed.format === 'image' ? 'Grafik Patern & Rasmlar' : parsed.format === 'xlsx' ? 'Moliyaviy Hisob & Risk' : 'Treyding Strategiyasi',
          format: parsed.format,
          size: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
          pagesCount: parsed.pagesCount,
          content: parsed.text,
          summary: extractedSummary.slice(0, 500) + '...',
          rules: [
            'Yuklangan hujjatdan ajratilgan asosiy strategiya qoidasi.',
            'MT5 bozori bilan solishtirish uchun indekslangan nuqtalar.',
          ],
          imagePreview: parsed.imagePreview,
          isPreloaded: false,
          isEnabled: true,
          dateAdded: new Date().toISOString().split('T')[0],
        };

        onAddBook(newBook);
      }
    } catch (err: any) {
      console.error('File parsing error:', err);
      setUploadError(`Faylni yuklashda xatolik: ${err.message}`);
    } finally {
      setIsUploading(false);
      // Reset input
      e.target.value = '';
    }
  };

  const filteredBooks = books.filter(b => {
    const matchesSearch = b.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          b.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          b.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = categoryFilter === 'ALL' || b.format === categoryFilter.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Top Banner explaining Knowledge-base & Copilot reasoning */}
      <div className="bg-gradient-to-r from-[#11192e] to-[#0e1628] rounded-2xl p-4 sm:p-5 border border-cyan-500/30 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-extrabold text-sm sm:text-base">
            <BookOpen className="w-5 h-5" />
            <h2>Treyding Kitoblari & Strategiyalar Bazasi</h2>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
            AI Copilot har bir javob va MT5 tahlilida aynan siz yuklagan kitoblar (PDF, Word DOCX, Excel, Patern rasmlari) qoidalariga asoslanadi. Istalgan kitobni yoqib yoki o'chirib qo'yishingiz mumkin.
          </p>
        </div>

        {/* Upload Button */}
        <label className="flex items-center justify-center gap-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-extrabold text-xs sm:text-sm px-5 py-2.5 rounded-xl shadow-lg shadow-cyan-500/20 active:scale-95 transition-all cursor-pointer whitespace-nowrap">
          <Upload className="w-4 h-4" />
          <span>{isUploading ? 'Yuklanmoqda...' : 'Yangi Kitob / Rasm Yuklash'}</span>
          <input
            type="file"
            multiple
            accept=".pdf,.doc,.docx,.xls,.xlsx,.csv,.txt,.png,.jpg,.jpeg,.webp"
            onChange={handleFileUpload}
            disabled={isUploading}
            className="hidden"
          />
        </label>
      </div>

      {uploadError && (
        <div className="bg-rose-950/60 border border-rose-500/60 rounded-xl p-3 text-xs text-rose-200">
          {uploadError}
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0f1524] p-3 rounded-2xl border border-slate-800">
        <div className="flex-1 min-w-[200px]">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Kitoblar, strategiyalar yoki muallif bo'yicha qidirish..."
            className="w-full bg-[#151e33] border border-slate-700/80 rounded-xl px-3.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-500 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Format:
          </span>
          {['ALL', 'PDF', 'DOCX', 'XLSX', 'IMAGE'].map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded-lg font-bold transition-all cursor-pointer ${categoryFilter === cat ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400 hover:text-white'}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Books Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredBooks.map((book) => (
          <div
            key={book.id}
            className={`bg-[#0d1322] rounded-2xl p-4 border transition-all flex flex-col justify-between gap-3 ${
              book.isEnabled ? 'border-cyan-500/40 shadow-lg shadow-cyan-950/20' : 'border-slate-800 opacity-60'
            }`}
          >
            <div>
              {/* Header with Format Badge and Toggle */}
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-md uppercase border ${
                    book.format === 'pdf' ? 'bg-rose-950/60 text-rose-300 border-rose-800' :
                    book.format === 'docx' ? 'bg-blue-950/60 text-blue-300 border-blue-800' :
                    book.format === 'xlsx' ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800' :
                    book.format === 'image' ? 'bg-purple-950/60 text-purple-300 border-purple-800' :
                    'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    {book.format}
                  </span>
                  <span className="text-xs font-semibold text-slate-400">{book.category}</span>
                </div>

                {/* Enable / Disable Toggle Switch */}
                <button
                  onClick={() => onToggleBook(book.id)}
                  className={`flex items-center gap-1.5 text-xs font-bold px-2.5 py-1 rounded-xl transition-all cursor-pointer ${
                    book.isEnabled
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-slate-800 text-slate-500 border border-slate-700'
                  }`}
                  title="Copilot ushbu kitobdan foydalansinmi?"
                >
                  <Check className={`w-3.5 h-3.5 ${book.isEnabled ? 'opacity-100' : 'opacity-0'}`} />
                  <span>{book.isEnabled ? 'Faol' : 'O\'chirilgan'}</span>
                </button>
              </div>

              {/* Title & Author */}
              <h3 className="font-extrabold text-white text-sm sm:text-base leading-snug line-clamp-2">
                {book.title}
              </h3>
              <div className="text-xs text-cyan-400/90 font-medium mt-0.5">
                Muallif: {book.author}
              </div>

              {/* Image Thumbnail Preview if image */}
              {book.imagePreview && (
                <div className="my-2 rounded-xl overflow-hidden border border-slate-800 max-h-36 bg-black flex items-center justify-center">
                  <img src={book.imagePreview} alt={book.title} className="object-contain h-36 w-full" />
                </div>
              )}

              {/* Summary */}
              <p className="text-xs text-slate-300 mt-2 line-clamp-3 leading-relaxed">
                {book.summary}
              </p>

              {/* Rules highlights */}
              {book.rules && book.rules.length > 0 && (
                <div className="mt-2.5 bg-[#090d18] p-2.5 rounded-xl border border-slate-800/80 space-y-1">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    Asosiy Qoidalar:
                  </div>
                  {book.rules.slice(0, 2).map((rule, idx) => (
                    <div key={idx} className="text-[11px] text-slate-300 flex items-start gap-1.5 leading-snug">
                      <span className="text-cyan-400">•</span>
                      <span>{rule}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-xs text-slate-400">
              <span className="text-[11px]">
                {book.pagesCount ? `${book.pagesCount} sahifa` : ''} ({book.size})
              </span>

              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => setSelectedBookForView(book)}
                  className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 text-slate-200 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>O'qish</span>
                </button>

                <button
                  onClick={() => onSelectForChat(book)}
                  className="flex items-center gap-1 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/80 px-2.5 py-1 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Savol so'rash</span>
                </button>

                {!book.isPreloaded && (
                  <button
                    onClick={() => onDeleteBook(book.id)}
                    className="p-1 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 cursor-pointer transition-colors"
                    title="O'chirish"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Book Reader Modal */}
      {selectedBookForView && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
          <div className="w-full max-w-2xl bg-[#0f1524] rounded-3xl border border-slate-700 shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="bg-[#141d33] p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded border border-cyan-800">
                  {selectedBookForView.format}
                </span>
                <h3 className="font-extrabold text-white text-base sm:text-lg mt-1">
                  {selectedBookForView.title}
                </h3>
                <div className="text-xs text-slate-400">
                  {selectedBookForView.author} • {selectedBookForView.category}
                </div>
              </div>
              <button
                onClick={() => setSelectedBookForView(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg bg-slate-800 text-xs px-2.5 py-1.5 cursor-pointer"
              >
                Yopish
              </button>
            </div>

            <div className="p-4 sm:p-6 overflow-y-auto space-y-4 text-xs sm:text-sm text-slate-200 leading-relaxed font-sans scrollbar-thin">
              {selectedBookForView.imagePreview && (
                <div className="rounded-xl overflow-hidden border border-slate-700 bg-black p-2 flex justify-center">
                  <img src={selectedBookForView.imagePreview} alt="Diagram" className="max-h-72 object-contain" />
                </div>
              )}

              <div className="bg-[#090d18] p-4 rounded-2xl border border-slate-800 space-y-2">
                <h4 className="font-bold text-cyan-400 text-sm">Strategiya va Asosiy Qoidalar:</h4>
                <ul className="space-y-1.5">
                  {selectedBookForView.rules.map((r, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-300">
                      <span className="text-cyan-400 font-bold">✓</span>
                      <span>{r}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="whitespace-pre-line bg-[#090e1c] p-4 rounded-2xl border border-slate-800/80 font-mono text-xs text-slate-300">
                {selectedBookForView.content}
              </div>
            </div>

            <div className="bg-[#12192c] p-4 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                AI ushbu kitob matnini to'liq eslab qoladi
              </span>
              <button
                onClick={() => {
                  onSelectForChat(selectedBookForView);
                  setSelectedBookForView(null);
                }}
                className="flex items-center gap-1.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs cursor-pointer shadow-md shadow-cyan-500/20"
              >
                <Sparkles className="w-4 h-4" />
                <span>Bu kitobdan savol so'rash</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
