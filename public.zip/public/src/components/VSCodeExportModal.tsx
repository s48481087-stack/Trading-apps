import React, { useState } from 'react';
import { Download, FileCode, Check, Copy, Folder, Smartphone, Terminal, ExternalLink, X, Archive, Sparkles } from 'lucide-react';
import JSZip from 'jszip';

interface VSCodeExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VSCodeExportModal: React.FC<VSCodeExportModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'zip' | 'files' | 'apk'>('zip');
  const [isGeneratingZip, setIsGeneratingZip] = useState(false);
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copiedFile, setCopiedFile] = useState(false);
  const [allFiles, setAllFiles] = useState<{ path: string; content: string }[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState(false);

  // Fetch files from server when modal opens
  React.useEffect(() => {
    if (!isOpen) return;
    setIsLoadingFiles(true);
    fetch('/api/export-files')
      .then(res => res.json())
      .then(data => {
        if (data.files && Array.isArray(data.files)) {
          setAllFiles(data.files);
        }
      })
      .catch(err => console.error(err))
      .finally(() => setIsLoadingFiles(false));
  }, [isOpen]);

  // Download entire project as ZIP
  const handleDownloadZip = async () => {
    setIsGeneratingZip(true);
    try {
      const zip = new JSZip();

      // Add all loaded files or fetch from server
      let filesToZip = allFiles;
      if (filesToZip.length === 0) {
        const res = await fetch('/api/export-files');
        const data = await res.json();
        filesToZip = data.files || [];
      }

      filesToZip.forEach(file => {
        zip.file(file.path, file.content);
      });

      // Add VS Code launcher and APK building instructions
      zip.file(
        'README.md',
        `# MT5 AI Copilot - Kitoblar & Bozor Tahlili

Ushbu loyiha VS Code da ochish va Android APK yaratish uchun to'liq tayyorlangan.

## 🚀 1. VS Code da ishga tushirish:
1. Ushbu arxivni papkaga chiqaring (Extract All).
2. VS Code dasturida papkani oching (\`File -> Open Folder\`).
3. Terminalni oching (\`Ctrl + \`\`):
   \`\`\`bash
   npm install
   npm run dev
   \`\`\`
4. Brauzeringizda oching: \`http://localhost:3000\`

## 📱 2. Android APK yaratish (2 ta qulay usul):

### 1-usul: PWA (Tezkor va o'rnatish oson)
- Saytni mobil brauzerda (Chrome) oching.
- Menyu (uch nuqta) -> "Ilovani o'rnatish" (Install App).
- Ilova telefoningiz ishchi stoliga alohida APK/ilova sifatida o'rnatiladi.

### 2-usul: Capacitor orqali Android Studio (.apk):
\`\`\`bash
npm run build
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "MT5 AI Copilot" "com.mt5.aicopilot" --web-dir dist
npx cap add android
npx cap open android
\`\`\`
Android Studio da: \`Build -> Build Bundle(s) / APK(s) -> Build APK(s)\`.

---
Muvaffaqiyatli treyding tilaymiz!
`
      );

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'mt5-ai-copilot-vscode.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err: any) {
      console.error('ZIP generation error:', err);
      alert(`ZIP yaratishda xatolik: ${err.message}`);
    } finally {
      setIsGeneratingZip(false);
    }
  };

  const handleCopyFileContent = (content: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="w-full max-w-4xl bg-[#0d1322] rounded-3xl border border-slate-700 shadow-2xl overflow-hidden flex flex-col h-[90vh] max-h-[780px]">
        {/* Modal Header */}
        <div className="bg-[#121a2f] p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-purple-600/30 border border-purple-500/50 flex items-center justify-center text-purple-300">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-white text-base sm:text-lg">
                VS Code Loyihasi & APK O'rnatish
              </h2>
              <div className="text-xs text-slate-400">
                To'liq kodlar bazasi, ZIP yuklab olish yoki fayllarni dona-dona nusxalash
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs Bar */}
        <div className="flex items-center gap-2 bg-[#090d18] px-4 py-2 border-b border-slate-800 text-xs sm:text-sm font-semibold">
          <button
            onClick={() => setActiveTab('zip')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl cursor-pointer transition-all ${
              activeTab === 'zip' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>ZIP Yuklab Olish</span>
          </button>

          <button
            onClick={() => setActiveTab('files')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl cursor-pointer transition-all ${
              activeTab === 'files' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>Fayllar (Dona-dona)</span>
          </button>

          <button
            onClick={() => setActiveTab('apk')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl cursor-pointer transition-all ${
              activeTab === 'apk' ? 'bg-purple-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>APK & Mobil O'rnatish</span>
          </button>
        </div>

        {/* Tab 1: ZIP Download & VS Code Instructions */}
        {activeTab === 'zip' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 scrollbar-thin text-xs sm:text-sm text-slate-300">
            <div className="bg-gradient-to-r from-purple-950/60 to-indigo-950/60 p-5 rounded-2xl border border-purple-500/40 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xl">
              <div>
                <h3 className="font-extrabold text-white text-base sm:text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-400" />
                  <span>Barcha kodlar bitta ZIP faylda</span>
                </h3>
                <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-xl leading-relaxed">
                  Loyihadagi barcha TypeScript, React komponentlari, MT5 grafigi, server API yo'nalishlari va sozlamalar fayllari jamlangan.
                </p>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={isGeneratingZip}
                className="flex items-center justify-center gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold px-6 py-3 rounded-2xl shadow-xl shadow-purple-600/30 cursor-pointer active:scale-95 transition-all whitespace-nowrap text-sm disabled:opacity-50"
              >
                <Download className="w-5 h-5" />
                <span>{isGeneratingZip ? 'ZIP Tayyorlanmoqda...' : 'ZIP Yuklab Olish (.zip)'}</span>
              </button>
            </div>

            {/* Step-by-step VS Code Guide */}
            <div className="bg-[#090d18] rounded-2xl p-4 sm:p-5 border border-slate-800 space-y-3">
              <h4 className="font-bold text-white text-sm flex items-center gap-2 text-cyan-400">
                <Terminal className="w-4 h-4" /> VS Code da ishga tushirish qadamlari:
              </h4>

              <div className="space-y-3 text-xs text-slate-300">
                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    1
                  </span>
                  <div>
                    <strong className="text-white">ZIP faylni oching:</strong> Yuklab olingan <code className="text-purple-300">mt5-ai-copilot-vscode.zip</code> arxivini kompyuteringizdagi istalgan papkaga chiqaring.
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    2
                  </span>
                  <div>
                    <strong className="text-white">VS Code dasturida oching:</strong> VS Code menyusidan <code className="text-cyan-300">File -&gt; Open Folder</code> bosib ochilgan papkani tanlang.
                  </div>
                </div>

                <div className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-bold flex items-center justify-center shrink-0 text-[10px]">
                    3
                  </span>
                  <div className="w-full">
                    <strong className="text-white">Terminalda o'rnating va yoqing:</strong>
                    <div className="bg-[#05070d] p-3 rounded-xl border border-slate-800 font-mono text-cyan-300 text-xs mt-1.5 space-y-1">
                      <div># Kutubxonalarni o'rnatish:</div>
                      <div className="text-emerald-400">npm install</div>
                      <div className="mt-2"># Serverni yoqish:</div>
                      <div className="text-emerald-400">npm run dev</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Dona-dona fayllar */}
        {activeTab === 'files' && (
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* File List Sidebar */}
            <div className="w-full md:w-64 bg-[#0a0e1a] border-r border-slate-800 p-2 overflow-y-auto max-h-48 md:max-h-full divide-y divide-slate-800/40">
              <div className="text-[10px] uppercase font-bold text-slate-500 px-2 py-1 flex items-center gap-1">
                <Folder className="w-3 h-3 text-cyan-400" /> Fayllar ro'yxati ({allFiles.length})
              </div>
              {allFiles.map((file, idx) => (
                <button
                  key={file.path}
                  onClick={() => setSelectedFileIndex(idx)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs font-mono truncate transition-colors cursor-pointer flex items-center gap-1.5 ${
                    selectedFileIndex === idx ? 'bg-purple-950/80 text-purple-300 font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
                  <span className="truncate">{file.path}</span>
                </button>
              ))}
            </div>

            {/* File Content Preview */}
            <div className="flex-1 bg-[#060911] p-3 sm:p-4 overflow-y-auto flex flex-col">
              {allFiles[selectedFileIndex] ? (
                <>
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-xs">
                    <span className="font-mono text-purple-300 font-bold">
                      {allFiles[selectedFileIndex].path}
                    </span>
                    <button
                      onClick={() => handleCopyFileContent(allFiles[selectedFileIndex].content)}
                      className="flex items-center gap-1 bg-purple-900/60 hover:bg-purple-800 text-purple-200 px-2.5 py-1 rounded-lg text-xs cursor-pointer active:scale-95 transition-all"
                    >
                      {copiedFile ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedFile ? 'Nusxalandi!' : 'Kodni nusxalash'}</span>
                    </button>
                  </div>
                  <pre className="font-mono text-xs text-slate-300 overflow-x-auto whitespace-pre leading-relaxed scrollbar-thin">
                    {allFiles[selectedFileIndex].content}
                  </pre>
                </>
              ) : (
                <div className="text-center py-12 text-slate-500 text-xs">
                  Faylni tanlang...
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 3: Android APK & PWA Guide */}
        {activeTab === 'apk' && (
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 scrollbar-thin text-xs sm:text-sm text-slate-300">
            <div className="bg-[#0f1524] rounded-2xl p-4 sm:p-5 border border-slate-800 space-y-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2 text-emerald-400">
                <Smartphone className="w-5 h-5" /> 1-Usul: Telefoningizga APK kabi o'rnatish (Eng tezkor & qulay):
              </h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Ushbu ilova to'liq <strong>PWA (Progressive Web App)</strong> texnologiyasida yaratilgan. Uni Android yoki iOS qurilmasida haqiqiy APK kabi ishlatish mumkin:
              </p>

              <ol className="list-decimal pl-5 space-y-2 text-xs text-slate-300">
                <li>Saytni Android telefoningizdagi <strong>Google Chrome</strong> brauzerida oching.</li>
                <li>Brauzerning yuqori o'ng burchagidagi <strong>uch nuqta (⋮)</strong> belgisini bosing.</li>
                <li><strong>"Ilovani o'rnatish" (Установить приложение / Add to Home screen)</strong> tugmasini bosing.</li>
                <li>Ilova telefoningiz ishchi stolida to'liq mustaqil APK ilova sifatida paydo bo'ladi va barcha funksiyalar (qo'ng'iroq, MT5 grafigi, kitoblar) ishlaydi!</li>
              </ol>
            </div>

            <div className="bg-[#0f1524] rounded-2xl p-4 sm:p-5 border border-slate-800 space-y-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2 text-cyan-400">
                <Terminal className="w-5 h-5" /> 2-Usul: Android Studio da .APK fayl yig'ish (Capacitor):
              </h3>

              <div className="bg-[#05070d] p-3.5 rounded-xl border border-slate-800 font-mono text-cyan-300 text-xs space-y-1.5">
                <div># 1. Loyihani build qilish:</div>
                <div className="text-emerald-400">npm run build</div>
                <div className="mt-2"># 2. Capacitor o'rnatish:</div>
                <div className="text-emerald-400">npm install @capacitor/core @capacitor/cli @capacitor/android</div>
                <div className="mt-2"># 3. Android loyihasini yaratish:</div>
                <div className="text-emerald-400">npx cap init "MT5 AI Copilot" "com.mt5.aicopilot" --web-dir dist</div>
                <div className="text-emerald-400">npx cap add android</div>
                <div className="mt-2"># 4. Android Studio ni ochish:</div>
                <div className="text-emerald-400">npx cap open android</div>
              </div>

              <div className="text-xs text-slate-400">
                Android Studio ochilgach, menyudan <strong>Build -&gt; Build APK(s)</strong> ni bossangiz, tayyor <code>app-debug.apk</code> faylini olasiz!
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
