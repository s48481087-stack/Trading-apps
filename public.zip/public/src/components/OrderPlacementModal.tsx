import React, { useState } from 'react';
import { X, ArrowUpRight, ArrowDownRight, ShieldAlert, CheckCircle2, Calculator } from 'lucide-react';
import { MarketAsset, TradePosition } from '../types.js';

interface OrderPlacementModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderType: 'BUY' | 'SELL';
  asset: MarketAsset;
  onConfirmOrder: (order: {
    symbol: string;
    type: 'BUY' | 'SELL';
    lots: number;
    openPrice: number;
    sl?: number;
    tp?: number;
    strategyNote: string;
  }) => void;
  balance: number;
}

export const OrderPlacementModal: React.FC<OrderPlacementModalProps> = ({
  isOpen,
  onClose,
  orderType,
  asset,
  onConfirmOrder,
  balance,
}) => {
  const currentPrice = orderType === 'BUY' ? asset.ask : asset.bid;

  const defaultSL = orderType === 'BUY'
    ? Number((currentPrice - (asset.currentPrice * 0.006)).toFixed(asset.decimals))
    : Number((currentPrice + (asset.currentPrice * 0.006)).toFixed(asset.decimals));

  const defaultTP = orderType === 'BUY'
    ? Number((currentPrice + (asset.currentPrice * 0.015)).toFixed(asset.decimals))
    : Number((currentPrice - (asset.currentPrice * 0.015)).toFixed(asset.decimals));

  const [lots, setLots] = useState(0.10);
  const [sl, setSl] = useState(defaultSL);
  const [tp, setTp] = useState(defaultTP);
  const [strategyNote, setStrategyNote] = useState('ICT Order Block & EMA 20 Rejection setup');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirmOrder({
      symbol: asset.symbol,
      type: orderType,
      lots,
      openPrice: currentPrice,
      sl: Number(sl),
      tp: Number(tp),
      strategyNote,
    });
    onClose();
  };

  // Calculate estimated risk & reward
  const slDistance = Math.abs(currentPrice - sl);
  const tpDistance = Math.abs(currentPrice - tp);
  const riskRewardRatio = slDistance > 0 ? (tpDistance / slDistance).toFixed(2) : '1:2';

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="w-full max-w-md bg-[#0f1524] rounded-3xl border border-slate-700 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between ${
          orderType === 'BUY'
            ? 'bg-emerald-950/60 border-emerald-800/80 text-emerald-300'
            : 'bg-rose-950/60 border-rose-800/80 text-rose-300'
        }`}>
          <div className="flex items-center gap-2">
            {orderType === 'BUY' ? <ArrowUpRight className="w-6 h-6" /> : <ArrowDownRight className="w-6 h-6" />}
            <div>
              <h3 className="font-extrabold text-base text-white">
                {orderType === 'BUY' ? 'BUY (Sotib Olish)' : 'SELL (Sotish)'} - {asset.symbol}
              </h3>
              <div className="text-xs text-slate-300 font-mono">
                Bozor narxi: ${currentPrice.toFixed(asset.decimals)}
              </div>
            </div>
          </div>

          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white bg-slate-800/80 cursor-pointer">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs sm:text-sm text-slate-300">
          {/* Lot Size Selector */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Lot Hajmi (Volume Lots):
            </label>
            <div className="flex items-center gap-2">
              {[0.01, 0.05, 0.10, 0.50, 1.0].map((val) => (
                <button
                  type="button"
                  key={val}
                  onClick={() => setLots(val)}
                  className={`flex-1 py-1.5 rounded-xl font-mono font-bold text-xs cursor-pointer transition-all ${
                    lots === val ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:text-white'
                  }`}
                >
                  {val}
                </button>
              ))}
            </div>
          </div>

          {/* Stop Loss & Take Profit */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-rose-400 mb-1">
                Stop Loss (SL):
              </label>
              <input
                type="number"
                step="any"
                value={sl}
                onChange={(e) => setSl(parseFloat(e.target.value))}
                className="w-full bg-[#151e33] border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-rose-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-emerald-400 mb-1">
                Take Profit (TP):
              </label>
              <input
                type="number"
                step="any"
                value={tp}
                onChange={(e) => setTp(parseFloat(e.target.value))}
                className="w-full bg-[#151e33] border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Risk Reward Ratio card */}
          <div className="bg-[#090d18] p-3 rounded-2xl border border-slate-800 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400 flex items-center gap-1">
              <Calculator className="w-3.5 h-3.5 text-cyan-400" /> Risk-Reward (R:R):
            </span>
            <span className="text-emerald-400 font-bold">1:{riskRewardRatio}</span>
          </div>

          {/* Strategy Note */}
          <div>
            <label className="block text-xs font-semibold text-slate-400 mb-1">
              Kitob Strategiyasi / Sababi:
            </label>
            <input
              type="text"
              value={strategyNote}
              onChange={(e) => setStrategyNote(e.target.value)}
              placeholder="Masalan: ICT Order block, Wyckoff Spring..."
              className="w-full bg-[#151e33] border border-slate-700 rounded-xl px-3 py-2 text-white text-xs focus:outline-none focus:border-cyan-500"
            />
          </div>

          {/* Submit button */}
          <button
            type="submit"
            className={`w-full py-3 rounded-2xl font-extrabold text-sm text-white shadow-xl cursor-pointer active:scale-95 transition-all ${
              orderType === 'BUY'
                ? 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                : 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
            }`}
          >
            {orderType === 'BUY' ? 'BUY Pozitsiyasini Ochish' : 'SELL Pozitsiyasini Ochish'} (${currentPrice.toFixed(asset.decimals)})
          </button>
        </form>
      </div>
    </div>
  );
};
