import React from 'react';
import { Phone, Download, Activity, BookOpen, Layers } from 'lucide-react';
import { MarketAsset } from '../types.js';

interface HeaderProps {
  assets: MarketAsset[];
  activeAsset: MarketAsset;
  activeBooksCount: number;
  onOpenCall: () => void;
  onOpenExport: () => void;
  accountBalance: number;
}

export const Header: React.FC<HeaderProps> = ({
  assets,
  activeAsset,
  activeBooksCount,
  onOpenCall,
  onOpenExport,
  accountBalance,
}) => {
  return (
    <header className="w-full bg-[#0d121c] border-b border-slate-800/80 sticky top-0 z-40">
      {/* Top Ticker Bar matching screenshot */}
      <div className="bg-[#080c14] border-b border-slate-800/60 px-3 py-1 text-[11px] font-mono flex items-center justify-between overflow-x-auto whitespace-nowrap scrollbar-none text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-cyan-400 font-semibold uppercase tracking-wider">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-500"></span>
            </span>
            <span>⚡ MT5 LIVE FEED:</span>
          </div>

          {assets.map((asset) => (
            <div key={asset.symbol} className="flex items-center gap-1.5">
              <span className="text-slate-300 font-bold">{asset.symbol}</span>
              <span className="text-white font-medium">
                ${asset.currentPrice.toLocaleString(undefined, { minimumFractionDigits: asset.decimals })}
              </span>
              <span className={asset.change24h >= 0 ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(2)}%
              </span>
            </div>
          ))}
        </div>

        <div className="hidden sm:flex items-center gap-3 text-slate-400 pl-4 border-l border-slate-800">
          <span className="text-emerald-400 flex items-center gap-1">
            <Activity className="w-3 h-3 text-emerald-400 animate-pulse" /> MT5 Server: Connected
          </span>
          <span className="text-slate-300 font-bold bg-slate-800/80 px-2 py-0.5 rounded text-[10px]">
            Balans: ${accountBalance.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Main App Bar matching user screenshot */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2 flex items-center justify-between gap-2">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          </div>
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-base sm:text-lg tracking-tight text-white leading-tight">
                MT5 AI Copilot
              </h1>
              <span className="bg-cyan-950/80 text-cyan-300 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded border border-cyan-800/60 leading-none">
                PRO v3.8
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-cyan-400/90 font-medium">
                <BookOpen className="w-3 h-3" />
                {activeBooksCount} ta kitob faol
              </span>
              <span className="text-slate-600">•</span>
              <span className="text-emerald-400 font-medium">{activeAsset.symbol} H1</span>
            </div>
          </div>
        </div>

        {/* Right Action Buttons matching screenshot */}
        <div className="flex items-center gap-2">
          {/* Green Phone Call Button */}
          <button
            onClick={onOpenCall}
            className="flex items-center gap-1.5 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white font-semibold text-xs sm:text-sm px-3.5 py-1.5 sm:py-2 rounded-xl shadow-md shadow-emerald-500/20 active:scale-95 transition-all cursor-pointer border border-emerald-400/30"
            title="AI ustoz bilan telefonda qo'ng'iroqdek gaplashish"
          >
            <Phone className="w-3.5 h-3.5 sm:w-4 sm:h-4 fill-white animate-bounce" />
            <span>Qo'ng'iroq</span>
          </button>

          {/* Purple ZIP Export Button */}
          <button
            onClick={onOpenExport}
            className="flex items-center gap-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs sm:text-sm px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl shadow-md shadow-purple-500/20 active:scale-95 transition-all cursor-pointer border border-purple-400/30"
            title="VS Code loyiha kodlari & ZIP yuklab olish"
          >
            <Download className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span>ZIP</span>
          </button>
        </div>
      </div>
    </header>
  );
};
