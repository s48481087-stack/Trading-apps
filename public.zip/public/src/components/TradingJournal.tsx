import React from 'react';
import { Plus, TrendingUp, TrendingDown, DollarSign, Award, Clock, CheckCircle, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TradePosition, MarketAsset } from '../types.js';

interface TradingJournalProps {
  balance: number;
  equity: number;
  positions: TradePosition[];
  closedTrades: TradePosition[];
  onClosePosition: (id: string) => void;
  onOpenOrderModal: (type: 'BUY' | 'SELL') => void;
  activeAsset: MarketAsset;
}

export const TradingJournal: React.FC<TradingJournalProps> = ({
  balance,
  equity,
  positions,
  closedTrades,
  onClosePosition,
  onOpenOrderModal,
  activeAsset,
}) => {
  const totalTrades = closedTrades.length;
  const winTrades = closedTrades.filter(t => (t.pnl || 0) > 0).length;
  const winRate = totalTrades > 0 ? ((winTrades / totalTrades) * 100).toFixed(1) : '0';
  const totalProfit = closedTrades.reduce((acc, t) => acc + (t.pnl || 0), 0);
  const floatingPnL = positions.reduce((acc, t) => acc + (t.pnl || 0), 0);

  const handleClose = (id: string, pnl: number) => {
    if (pnl > 0) {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
      });
    }
    onClosePosition(id);
  };

  return (
    <div className="w-full flex flex-col gap-4">
      {/* Account Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-[#0f1524] rounded-2xl p-3.5 border border-slate-800 shadow-lg">
          <div className="text-[11px] text-slate-400 font-medium">Balans (Balance)</div>
          <div className="text-base sm:text-lg font-extrabold text-white font-mono mt-1">
            ${balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-cyan-400 mt-0.5">MT5 Virtual Hisob</div>
        </div>

        <div className="bg-[#0f1524] rounded-2xl p-3.5 border border-slate-800 shadow-lg">
          <div className="text-[11px] text-slate-400 font-medium">Ekviti (Equity)</div>
          <div className={`text-base sm:text-lg font-extrabold font-mono mt-1 ${equity >= balance ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${equity.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Suzuvchi P&L: {floatingPnL >= 0 ? '+' : ''}${floatingPnL.toFixed(2)}
          </div>
        </div>

        <div className="bg-[#0f1524] rounded-2xl p-3.5 border border-slate-800 shadow-lg">
          <div className="text-[11px] text-slate-400 font-medium">Win Rate (Yutuq %)</div>
          <div className="text-base sm:text-lg font-extrabold text-amber-300 font-mono mt-1">
            {winRate}%
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {winTrades} yutuq / {totalTrades} ta bitim
          </div>
        </div>

        <div className="bg-[#0f1524] rounded-2xl p-3.5 border border-slate-800 shadow-lg">
          <div className="text-[11px] text-slate-400 font-medium">Foyda / Zarar</div>
          <div className={`text-base sm:text-lg font-extrabold font-mono mt-1 ${totalProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
            {totalProfit >= 0 ? '+' : ''}${totalProfit.toFixed(2)}
          </div>
          <div className="text-[10px] text-slate-400 mt-0.5">Kitob qoidalariga rioya</div>
        </div>
      </div>

      {/* Active Positions Section */}
      <div className="bg-[#0d1322] rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-white text-sm sm:text-base">
              Ochiq Pozitsiyalar ({positions.length})
            </h3>
            <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono">
              Live MT5 PnL
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onOpenOrderModal('BUY')}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs px-3 py-1.5 rounded-xl cursor-pointer shadow-md shadow-emerald-600/20 active:scale-95 transition-all"
            >
              + Buy Ochish
            </button>
            <button
              onClick={() => onOpenOrderModal('SELL')}
              className="bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs px-3 py-1.5 rounded-xl cursor-pointer shadow-md shadow-rose-600/20 active:scale-95 transition-all"
            >
              + Sell Ochish
            </button>
          </div>
        </div>

        {positions.length === 0 ? (
          <div className="text-center py-8 text-slate-500 text-xs">
            Hozircha ochiq bitimlar yo'q. Grafikdan yoki yuqoridagi tugmalardan bitim ochishingiz mumkin.
          </div>
        ) : (
          <div className="space-y-2.5">
            {positions.map((pos) => (
              <div
                key={pos.id}
                className="bg-[#12192c] p-3.5 rounded-xl border border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5">
                  <span className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] uppercase font-mono ${
                    pos.type === 'BUY' ? 'bg-emerald-950 text-emerald-300 border border-emerald-700' : 'bg-rose-950 text-rose-300 border border-rose-700'
                  }`}>
                    {pos.type} {pos.lots} lot
                  </span>
                  <div>
                    <div className="font-bold text-white text-sm">{pos.symbol}</div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Kirish: ${pos.openPrice} | Joriy: ${pos.currentPrice}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right font-mono">
                    <div className={`font-extrabold text-sm ${pos.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {pos.pnl >= 0 ? '+' : ''}${pos.pnl.toFixed(2)}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      SL: {pos.sl || 'Yo\'q'} | TP: {pos.tp || 'Yo\'q'}
                    </div>
                  </div>

                  <button
                    onClick={() => handleClose(pos.id, pos.pnl)}
                    className="bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer active:scale-95 transition-all"
                  >
                    Yopish
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Closed Trades History */}
      <div className="bg-[#0d1322] rounded-2xl p-4 border border-slate-800 shadow-xl flex flex-col gap-3">
        <h3 className="font-extrabold text-white text-sm sm:text-base">
          Yopilgan Bitimlar Tarixi ({closedTrades.length})
        </h3>

        {closedTrades.length === 0 ? (
          <div className="text-center py-6 text-slate-500 text-xs">
            Bitimlar yopilganda ularning to'liq tahlili va natijasi bu yerda aks etadi.
          </div>
        ) : (
          <div className="space-y-2">
            {closedTrades.slice(-10).reverse().map((trade) => (
              <div
                key={trade.id}
                className="bg-[#12192c] p-3 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-2">
                  <span className={`px-2 py-0.5 rounded font-mono font-bold text-[10px] ${
                    trade.type === 'BUY' ? 'text-emerald-400 bg-emerald-950/60' : 'text-rose-400 bg-rose-950/60'
                  }`}>
                    {trade.type}
                  </span>
                  <div>
                    <div className="font-bold text-white">{trade.symbol} ({trade.lots} lot)</div>
                    <div className="text-[10px] text-slate-400">{trade.strategyNote || 'Kitob strategiyasi'}</div>
                  </div>
                </div>

                <div className="text-right font-mono">
                  <div className={`font-bold ${trade.pnl >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                  </div>
                  <div className="text-[10px] text-slate-500">{trade.closeTime || 'Yopilgan'}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
