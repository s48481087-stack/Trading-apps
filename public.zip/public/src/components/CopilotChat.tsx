import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Sparkles, BookOpen, Image as ImageIcon, X, Copy, Check, Volume2 } from 'lucide-react';
import { ChatMessage, MarketAsset, BookItem } from '../types.js';

interface CopilotChatProps {
  messages: ChatMessage[];
  onSendMessage: (text: string, image?: string) => Promise<void>;
  activeAsset: MarketAsset;
  activeBooks: BookItem[];
  preselectedPrompt?: string;
  onClearPreselectedPrompt?: () => void;
}

export const CopilotChat: React.FC<CopilotChatProps> = ({
  messages,
  onSendMessage,
  activeAsset,
  activeBooks,
  preselectedPrompt,
  onClearPreselectedPrompt,
}) => {
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (preselectedPrompt) {
      setInputText(preselectedPrompt);
      if (onClearPreselectedPrompt) onClearPreselectedPrompt();
    }
  }, [preselectedPrompt]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isSending]);

  const handleSend = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if ((!inputText.trim() && !selectedImage) || isSending) return;

    const textToSend = inputText.trim();
    const imageToSend = selectedImage || undefined;

    setInputText('');
    setSelectedImage(null);
    setIsSending(true);

    try {
      await onSendMessage(textToSend, imageToSend);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSending(false);
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      setSelectedImage(reader.result as string);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (text: string) => {
    if (typeof window === 'undefined' || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*#_`>]/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.05;
    window.speechSynthesis.speak(utterance);
  };

  const quickPrompts = [
    `Hozirgi ${activeAsset.symbol} grafigida ICT Order Block & FVG bormi?`,
    `Wyckoff metodologiyasi bo'yicha bu qaysi faza (Accumulation yoki Markup)?`,
    `Kitobimdagi Risk menejmenti bo'yicha 1:3 R:R kirish nuqtasi tuzib ber`,
    `$10,000 depozit va 20 pip SL uchun xavfsiz lot hajmini hisobla`,
  ];

  return (
    <div className="w-full flex flex-col h-[75vh] max-h-[720px] bg-[#0c1220] rounded-3xl border border-slate-800 shadow-2xl overflow-hidden">
      {/* Chat Header */}
      <div className="bg-[#11192e] px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-md shadow-cyan-500/20">
            <Bot className="w-4 h-4" />
          </div>
          <div>
            <h2 className="font-extrabold text-sm sm:text-base text-white flex items-center gap-2">
              <span>MT5 AI Copilot</span>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-800 font-mono">
                {activeAsset.symbol} ${activeAsset.currentPrice.toFixed(activeAsset.decimals)}
              </span>
            </h2>
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <BookOpen className="w-3 h-3 text-cyan-400" />
              <span>{activeBooks.length} ta faol kitobga asoslanadi</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1 text-xs text-slate-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span className="text-emerald-400 font-medium">Jonli</span>
        </div>
      </div>

      {/* Messages List */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4 scrollbar-thin text-xs sm:text-sm">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 text-[10px] text-slate-500 mb-1 px-1">
              {msg.sender === 'user' ? (
                <><span>Siz</span> <User className="w-3 h-3 text-cyan-400" /></>
              ) : (
                <><Bot className="w-3 h-3 text-emerald-400" /> <span>MT5 AI Copilot</span></>
              )}
              <span>{msg.timestamp}</span>
            </div>

            <div
              className={`max-w-[90%] sm:max-w-[80%] rounded-2xl p-3.5 leading-relaxed shadow-lg ${
                msg.sender === 'user'
                  ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-br-none'
                  : 'bg-[#141c30] text-slate-200 border border-slate-700/80 rounded-bl-none'
              }`}
            >
              {/* Attached Image if present */}
              {msg.imageAttachment && (
                <div className="mb-2 rounded-xl overflow-hidden border border-slate-700 max-h-48">
                  <img src={msg.imageAttachment} alt="Attachment" className="object-contain w-full" />
                </div>
              )}

              {/* Message Content */}
              <div className="whitespace-pre-line leading-relaxed">
                {msg.text}
              </div>

              {/* Citations from user books */}
              {msg.citedBooks && msg.citedBooks.length > 0 && (
                <div className="mt-3 pt-2.5 border-t border-slate-700/60 flex flex-wrap items-center gap-1.5 text-[10px]">
                  <span className="text-cyan-400 font-bold flex items-center gap-1">
                    <BookOpen className="w-3 h-3" /> Manbalar:
                  </span>
                  {msg.citedBooks.map((b, i) => (
                    <span key={i} className="bg-cyan-950/80 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-800">
                      {b}
                    </span>
                  ))}
                </div>
              )}

              {/* Assistant Message Actions */}
              {msg.sender === 'assistant' && (
                <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-end gap-2 text-slate-400">
                  <button
                    onClick={() => handleSpeak(msg.text)}
                    className="p-1 hover:text-cyan-300 rounded cursor-pointer"
                    title="Ovozli o'qish"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleCopy(msg.id, msg.text)}
                    className="p-1 hover:text-cyan-300 rounded cursor-pointer flex items-center gap-1 text-[10px]"
                    title="Nusxalash"
                  >
                    {copiedId === msg.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === msg.id ? 'Nusxalandi' : ''}</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}

        {isSending && (
          <div className="flex items-center gap-2 text-cyan-400 italic text-xs bg-[#12192b] p-3 rounded-2xl border border-slate-800 w-fit">
            <Sparkles className="w-4 h-4 animate-spin text-cyan-400" />
            <span>Kitoblar tahlil qilinmoqda va MT5 grafigi tekshirilmoqda...</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Prompts Carousel */}
      <div className="bg-[#0b101c] px-3 py-2 border-t border-slate-800/80 overflow-x-auto whitespace-nowrap scrollbar-none flex items-center gap-2 text-xs">
        {quickPrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => setInputText(prompt)}
            className="bg-[#141d30] hover:bg-[#1a253d] text-slate-300 border border-slate-700/80 px-3 py-1 rounded-full text-[11px] cursor-pointer transition-all active:scale-95"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Selected Image Preview in Input */}
      {selectedImage && (
        <div className="px-4 py-2 bg-[#121a2d] border-t border-slate-800 flex items-center gap-2">
          <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-cyan-500">
            <img src={selectedImage} alt="Selected" className="object-cover w-full h-full" />
            <button
              onClick={() => setSelectedImage(null)}
              className="absolute top-0 right-0 bg-black/80 text-white rounded-bl p-0.5 cursor-pointer"
            >
              <X className="w-3 h-3" />
            </button>
          </div>
          <span className="text-xs text-cyan-300">Rasm biriktirildi (AI rasm va grafik paternini tahlil qiladi)</span>
        </div>
      )}

      {/* Chat Input Bar */}
      <form onSubmit={handleSend} className="bg-[#0e1424] p-3 border-t border-slate-800 flex items-center gap-2">
        <input
          type="file"
          ref={fileInputRef}
          accept="image/png,image/jpeg,image/webp"
          onChange={handleImageSelect}
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2.5 rounded-xl bg-[#162035] hover:bg-[#1d2b47] text-slate-300 hover:text-cyan-400 border border-slate-700/80 cursor-pointer transition-colors"
          title="Grafik rasmi yoki diagramma yuklash"
        >
          <ImageIcon className="w-4 h-4" />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={`Kitoblar bo'yicha ${activeAsset.symbol} haqida savol bering...`}
          className="flex-1 bg-[#141d30] border border-slate-700/80 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
        />

        <button
          type="submit"
          disabled={(!inputText.trim() && !selectedImage) || isSending}
          className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 disabled:opacity-50 text-slate-950 font-bold p-2.5 rounded-xl cursor-pointer shadow-lg shadow-cyan-500/20 active:scale-95 transition-all"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};
