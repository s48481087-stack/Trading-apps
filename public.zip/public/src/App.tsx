import React, { useState, useEffect } from 'react';
import { LineChart, BookOpen, Phone, MessageSquare, BookMarked, Smartphone, Sparkles, Download, Layers } from 'lucide-react';
import { Header } from './components/Header.js';
import { ChartSection } from './components/ChartSection.js';
import { BooksLibrary } from './components/BooksLibrary.js';
import { CopilotChat } from './components/CopilotChat.js';
import { TradingJournal } from './components/TradingJournal.js';
import { PhoneCallModal } from './components/PhoneCallModal.js';
import { VSCodeExportModal } from './components/VSCodeExportModal.js';
import { OrderPlacementModal } from './components/OrderPlacementModal.js';
import { INITIAL_ASSETS, generateCandlestickHistory } from './data/marketAssets.js';
import { DEFAULT_TRADING_BOOKS } from './data/defaultBooks.js';
import { MarketAsset, Candle, Timeframe, BookItem, ChatMessage, TradePosition } from './types.js';

type ActiveTab = 'chart' | 'books' | 'copilot' | 'journal';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('chart');
  const [assets, setAssets] = useState<MarketAsset[]>(INITIAL_ASSETS);
  const [activeAsset, setActiveAsset] = useState<MarketAsset>(INITIAL_ASSETS[0]); // XAUUSD
  const [timeframe, setTimeframe] = useState<Timeframe>('H1');
  const [candles, setCandles] = useState<Candle[]>([]);

  // Books state
  const [books, setBooks] = useState<BookItem[]>(DEFAULT_TRADING_BOOKS);

  // Chat state
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome-msg',
      sender: 'assistant',
      text: `Assalomu alaykum! Men sizning MT5 AI Copilot treyding tahlilchingizman.\n\nSiz yuklagan kitoblar (ICT, Wyckoff, Price Action, Risk Management) va MT5 real vaqt grafigi asosida xolis va asosli maslahat beraman.\n\n🎙️ Eslatma: Yuqoridagi "Qo'ng'iroq" tugmasi orqali xuddi telefonda gaplashgandek jonli ovozli maslahat olishingiz mumkin!`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      citedBooks: ['Smart Money Concepts & ICT', 'The Wyckoff Method'],
    },
  ]);
  const [preselectedPrompt, setPreselectedPrompt] = useState<string | undefined>(undefined);

  // Paper Trading state
  const [balance, setBalance] = useState(10000.0);
  const [positions, setPositions] = useState<TradePosition[]>([
    {
      id: 'pos-init-1',
      symbol: 'XAUUSD',
      type: 'BUY',
      openPrice: 2874.50,
      currentPrice: 2882.10,
      sl: 2865.00,
      tp: 2905.00,
      lots: 0.20,
      openTime: '10:30',
      pnl: 152.00,
      status: 'OPEN',
      strategyNote: 'ICT H1 Order block va EMA 20 bounce',
    },
  ]);
  const [closedTrades, setClosedTrades] = useState<TradePosition[]>([]);

  // Modals
  const [isCallOpen, setIsCallOpen] = useState(false);
  const [isExportOpen, setIsExportOpen] = useState(false);
  const [orderModalData, setOrderModalData] = useState<{ isOpen: boolean; type: 'BUY' | 'SELL' }>({
    isOpen: false,
    type: 'BUY',
  });

  // Load initial candles on asset / timeframe change
  useEffect(() => {
    const newCandles = generateCandlestickHistory(activeAsset.symbol, timeframe, 70);
    setCandles(newCandles);
  }, [activeAsset.symbol, timeframe]);

  // Real-time MT5 Ticker simulation (updates prices every 1.5 seconds)
  useEffect(() => {
    const interval = setInterval(() => {
      setAssets((prevAssets) =>
        prevAssets.map((asset) => {
          const deltaFactor = asset.symbol === 'BTCUSD' ? 4.5 : asset.symbol === 'XAUUSD' ? 0.35 : 0.00015;
          const randomChange = (Math.random() - 0.49) * deltaFactor;
          const newPrice = Number((asset.currentPrice + randomChange).toFixed(asset.decimals));
          const newBid = newPrice;
          const newAsk = Number((newPrice + asset.spread).toFixed(asset.decimals));

          return {
            ...asset,
            currentPrice: newPrice,
            bid: newBid,
            ask: newAsk,
          };
        })
      );

      // Also update active asset and last candlestick
      setActiveAsset((curr) => {
        const deltaFactor = curr.symbol === 'BTCUSD' ? 4.5 : curr.symbol === 'XAUUSD' ? 0.35 : 0.00015;
        const randomChange = (Math.random() - 0.49) * deltaFactor;
        const newPrice = Number((curr.currentPrice + randomChange).toFixed(curr.decimals));
        const newBid = newPrice;
        const newAsk = Number((newPrice + curr.spread).toFixed(curr.decimals));

        // Update last candle in place
        setCandles((prevCandles) => {
          if (prevCandles.length === 0) return prevCandles;
          const last = { ...prevCandles[prevCandles.length - 1] };
          last.close = newPrice;
          if (newPrice > last.high) last.high = newPrice;
          if (newPrice < last.low) last.low = newPrice;
          return [...prevCandles.slice(0, -1), last];
        });

        // Update positions floating PnL
        setPositions((prevPositions) =>
          prevPositions.map((pos) => {
            if (pos.symbol === curr.symbol) {
              const diff = pos.type === 'BUY' ? newPrice - pos.openPrice : pos.openPrice - newPrice;
              const multiplier = pos.symbol === 'XAUUSD' ? 100 : pos.symbol.includes('USD') && !pos.symbol.includes('JPY') ? 100000 : 10;
              const pnl = Number((diff * pos.lots * multiplier).toFixed(2));
              return { ...pos, currentPrice: newPrice, pnl };
            }
            return pos;
          })
        );

        return {
          ...curr,
          currentPrice: newPrice,
          bid: newBid,
          ask: newAsk,
        };
      });
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  const activeBooks = books.filter(b => b.isEnabled);

  // Send message to Copilot chat
  const handleSendMessage = async (text: string, image?: string) => {
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      imageAttachment: image,
    };

    setMessages((prev) => [...prev, userMsg]);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          chatHistory: messages.slice(-6),
          market: {
            symbol: activeAsset.symbol,
            displayName: activeAsset.displayName,
            currentPrice: activeAsset.currentPrice,
            trend: activeAsset.trend,
            ema20: activeAsset.currentPrice * 0.992,
            ema50: activeAsset.currentPrice * 0.985,
            rsi: 61.5,
          },
          books: activeBooks.map((b) => ({
            id: b.id,
            name: b.title,
            category: b.category,
            content: b.content,
          })),
          image: image ? { base64: image.split(',')[1] || image, mimeType: 'image/png' } : undefined,
        }),
      });

      const data = await response.json();
      const assistantText = data.text || 'Tahlil yakunlandi.';

      const cited = activeBooks.filter(b => assistantText.toLowerCase().includes(b.category.toLowerCase()) || assistantText.toLowerCase().includes(b.title.toLowerCase().slice(0, 10))).map(b => b.title);

      const assistantMsg: ChatMessage = {
        id: `assistant-${Date.now()}`,
        sender: 'assistant',
        text: assistantText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        citedBooks: cited.length > 0 ? cited : [activeBooks[0]?.title || 'Kitoblar tahlili'],
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error(err);
      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        sender: 'assistant',
        text: 'Aloqa xatoligi yuz berdi. Iltimos qaytadan urinib ko\'ring.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMsg]);
    }
  };

  // Open position
  const handleConfirmOrder = (order: {
    symbol: string;
    type: 'BUY' | 'SELL';
    lots: number;
    openPrice: number;
    sl?: number;
    tp?: number;
    strategyNote: string;
  }) => {
    const newPos: TradePosition = {
      id: `pos-${Date.now()}`,
      symbol: order.symbol,
      type: order.type,
      openPrice: order.openPrice,
      currentPrice: order.openPrice,
      sl: order.sl,
      tp: order.tp,
      lots: order.lots,
      openTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      pnl: 0,
      status: 'OPEN',
      strategyNote: order.strategyNote,
    };

    setPositions((prev) => [newPos, ...prev]);
  };

  // Close position
  const handleClosePosition = (id: string) => {
    const pos = positions.find((p) => p.id === id);
    if (!pos) return;

    setBalance((prev) => prev + pos.pnl);
    setPositions((prev) => prev.filter((p) => p.id !== id));
    setClosedTrades((prev) => [
      ...prev,
      {
        ...pos,
        status: 'CLOSED',
        closePrice: pos.currentPrice,
        closeTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Floating Equity
  const equity = balance + positions.reduce((acc, p) => acc + (p.pnl || 0), 0);

  return (
    <div className="min-h-screen bg-[#0b0e14] text-slate-100 flex flex-col font-sans pb-20 md:pb-6">
      {/* Top Header matching user screenshot */}
      <Header
        assets={assets}
        activeAsset={activeAsset}
        activeBooksCount={activeBooks.length}
        onOpenCall={() => setIsCallOpen(true)}
        onOpenExport={() => setIsExportOpen(true)}
        accountBalance={balance}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-2 sm:px-4 py-3 sm:py-4">
        {activeTab === 'chart' && (
          <ChartSection
            assets={assets}
            activeAsset={activeAsset}
            onSelectAsset={(asset) => setActiveAsset(asset)}
            candles={candles}
            timeframe={timeframe}
            onChangeTimeframe={(tf) => setTimeframe(tf)}
            activeBooks={activeBooks}
            onOpenOrderModal={(type) => setOrderModalData({ isOpen: true, type })}
          />
        )}

        {activeTab === 'books' && (
          <BooksLibrary
            books={books}
            onToggleBook={(id) => {
              setBooks(prev => prev.map(b => b.id === id ? { ...b, isEnabled: !b.isEnabled } : b));
            }}
            onAddBook={(book) => setBooks(prev => [book, ...prev])}
            onDeleteBook={(id) => setBooks(prev => prev.filter(b => b.id !== id))}
            onSelectForChat={(book) => {
              setActiveTab('copilot');
              setPreselectedPrompt(`"${book.title}" kitobidagi asosiy qoidalarga asosan hozirgi ${activeAsset.symbol} grafigiga qanday strategiya mos keladi?`);
            }}
          />
        )}

        {activeTab === 'copilot' && (
          <CopilotChat
            messages={messages}
            onSendMessage={handleSendMessage}
            activeAsset={activeAsset}
            activeBooks={activeBooks}
            preselectedPrompt={preselectedPrompt}
            onClearPreselectedPrompt={() => setPreselectedPrompt(undefined)}
          />
        )}

        {activeTab === 'journal' && (
          <TradingJournal
            balance={balance}
            equity={equity}
            positions={positions}
            closedTrades={closedTrades}
            onClosePosition={handleClosePosition}
            onOpenOrderModal={(type) => setOrderModalData({ isOpen: true, type })}
            activeAsset={activeAsset}
          />
        )}
      </main>

      {/* Bottom Navigation Bar matching user screenshot exactly */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#090d18]/95 backdrop-blur-md border-t border-slate-800/90 px-3 py-1.5 flex items-center justify-around max-w-md mx-auto md:max-w-xl md:rounded-t-3xl md:bottom-2 shadow-2xl">
        {/* Tab 1: Grafik */}
        <button
          onClick={() => setActiveTab('chart')}
          className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'chart' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <LineChart className="w-5 h-5" />
          <span className="text-[11px] font-medium">Grafik</span>
        </button>

        {/* Tab 2: Kitoblar */}
        <button
          onClick={() => setActiveTab('books')}
          className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'books' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <BookOpen className="w-5 h-5" />
          <span className="text-[11px] font-medium">Kitoblar</span>
        </button>

        {/* Center Big Glowing Green Call Button */}
        <button
          onClick={() => setIsCallOpen(true)}
          className="relative -top-3 w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-white shadow-xl shadow-emerald-500/40 ring-4 ring-[#0b0e14] active:scale-90 transition-all cursor-pointer"
          title="Telefonda AI Ustoz bilan jonli gaplashish"
        >
          <Phone className="w-6 h-6 fill-white animate-bounce" />
        </button>

        {/* Tab 4: Copilot */}
        <button
          onClick={() => setActiveTab('copilot')}
          className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'copilot' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <MessageSquare className="w-5 h-5" />
          <span className="text-[11px] font-medium">Copilot</span>
        </button>

        {/* Tab 5: Jurnal */}
        <button
          onClick={() => setActiveTab('journal')}
          className={`flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'journal' ? 'text-cyan-400 font-extrabold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <BookMarked className="w-5 h-5" />
          <span className="text-[11px] font-medium">Jurnal</span>
        </button>
      </nav>

      {/* Modals */}
      <PhoneCallModal
        isOpen={isCallOpen}
        onClose={() => setIsCallOpen(false)}
        activeAsset={activeAsset}
        activeBooks={activeBooks}
      />

      <VSCodeExportModal
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
      />

      <OrderPlacementModal
        isOpen={orderModalData.isOpen}
        onClose={() => setOrderModalData({ isOpen: false, type: 'BUY' })}
        orderType={orderModalData.type}
        asset={activeAsset}
        onConfirmOrder={handleConfirmOrder}
        balance={balance}
      />
    </div>
  );
}
